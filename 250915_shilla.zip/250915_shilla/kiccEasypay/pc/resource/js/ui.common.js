"use strict";

var SUI = SUI || {}; /* global namespace */

/*********************************
 * utils
 *
 * // get scrollTop
 * @method SUI.Utils.ScrollTop();
 *
 * // RequestAF
 * @param {Function} cb requestAnimationFrame callback
 *
 * // LayerZindex
 * @method SUI.Utils.LayerZindex(popup,current);
 * @param {Element} popup  filter visible layer popup element
 * @param {Element} current open layer element
 *
 * // ScrollListener
 * @method SUI.Utils.ScrollListener(target,fn);
 * @param {Object} target scroll target window or document
 * @param {Function} fn scroll event actions
 *
 * // toggleClass
 * @method SUI.Utils.toggleClass(t,className);
 * @param {Element} t add class element
 * @param {String} className add class name
 *
 * // move to top
 * @method SUI.Utils.top();
 *
 * // etc jquery method
 * @method SUI.Utils.toggle(t); {Selector parant} t
 * @method SUI.Utils.fadeIn(t); {Selector} t
 * @method SUI.Utils.fadeOut(t); {Selector} t
 *
 * // load, backspace BFCache call function
 * @method SUI.Utils.loadFn(fn)
 * @param {Function} fn
 *
 **********************************/

// IE11 forEach supporting
if (window.NodeList && !NodeList.prototype.forEach) {
    NodeList.prototype.forEach = Array.prototype.forEach;
}
// IE11 closest supporting
if (!Element.prototype.closest) {
    Element.prototype.closest = function(css) {
        var node = this;
        while (node) {
            if (node.matches(css)) return node;
            else node = node.parentElement;
        }
        return null;
    };
}
if (!Element.prototype.matches) {
    Element.prototype.matches =
        Element.prototype.matchesSelector || Element.prototype.webkitMatchesSelector ||
        Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector;
}
// IE11 assign supporting
if (typeof Object.assign != "function") {
    Object.defineProperty(Object, "assign", {
        value: function assign(target, varArgs) {
            if (target == null) {
                throw new TypeError("Cannot convert undefined or null to object");
            }
            var to = Object(target);
            for (var index = 1; index < arguments.length; index++) {
                var nextSource = arguments[index];
                if (nextSource != null) {
                    for (var nextKey in nextSource) {
                        if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
                            to[nextKey] = nextSource[nextKey];
                        }
                    }
                }
            }
            return to;
        },
        writable: true,
        configurable: true
    });
}

SUI.Utils = {
    ScrollTop: function() {
        var scrollTop = window.scrollTop || document.documentElement.scrollTop || document.body.scrollTop;
        return scrollTop;
    },

    RequestAF: function(cb) {
        var rAfTimeout = null;
        return function() {
            if (rAfTimeout) {
                window.cancelAnimationFrame(rAfTimeout);
            }
            rAfTimeout = window.requestAnimationFrame(function() {
                cb();
            })
        }
    },

    LayerZindex: function(popups, current) {
        if (popups === 'layer') {
            popups = $('[data-alert], [data-full-layer]').filter(':visible');
        }
        if (popups.length !== 0) {
            var idx = 0;
            popups.each(function(index) {
                idx = Math.max(parseInt($(this).css('zIndex')), idx);
            });
            current.css({
                'z-index': idx + 1
            });
        }
    },

    ScrollListener: function(target, fn, name, opt) {
        var requestAF = name !== undefined ? 'requestAF_' + name : 'requestAF';
        if (name !== undefined && target[requestAF] !== undefined) {
            target.removeEventListener('scroll', target[requestAF]);
        }
        return target.addEventListener('scroll', target[requestAF] = this.RequestAF(function() {
            if (typeof fn === 'function') {
                fn();
            } else {
                window[fn].call();
            }
        }, target), Object.assign({
            capture : false,
            once : false,
            passive : false,
        }, opt));
    },

    toggleClass: function(t, className) {
        $(t).toggleClass(className);
    },

    toggle: function(t) {
        $(t).parent().toggleClass('on');
    },

    top: function() {
        return $('html, body').stop().animate({
            scrollTop: 0
        }, 300);
    },

    fadeIn: function(t) {
        return $(t).fadeIn('fast');
    },

    fadeOut: function(t) {
        return $(t).fadeOut('fast');
    },

    loadFn: function(fn) {
        // reload
        $(function() {
            fn();
        })
        // backspace BFCache
        window.onpageshow = function(event) {
            if (event.persisted) fn();
        };
    },

    overlap : function(target, handler, fn){
        target.handler && target.removeEventListener(handler, target.handler);
        target.handler = fn;
        target.addEventListener(handler, target.handler);
    }
}

/*********************************
 *
 **********************************/
SUI.Alert = {
    _element: function(t) {
        this.el = null;
        this.getAtt = t;
        this.el = document.querySelector('[data-alert=' + this.getAtt + ']');
    },

    show: function(t) {
        var me = this;
        this._element(t);

        if (!this.el) {
            console.log('%c error: data-alert element not found', 'background: #222; color: #bada55');
        }

        // show transition
        this.el.classList.add('show');
        setTimeout(function() {
            me.el.classList.add('isAnimate');
        }, 50);
    },

    hide: function(t, callback) {
        var me = this;
        if (t !== this.getAtt) return;

        this.el.classList.remove('isAnimate');
        setTimeout(function() {
            me.el.classList.remove('show');
        }, 100);

        // callback
        try {
            if (callback) {
                setTimeout(function() {
                   
                    if (typeof callback === 'function') {
                        callback();
                    } else {
                        window[callback].call();
                    }
                }, 280)
            }
        } catch (e) {
            console.log(e);
        }
    }
}

/*********************************

 *
 * @method SUI.FullLayer.show(t);
 * @method SUI.FullLayer.hide(t);
 * @param {String} t data-actionsheet value
 *
 **********************************/
SUI.FullLayer = {
    _element: function(t) {
        this.el = null;
        this.getAtt = t;
        this.el = document.querySelector('[data-full-layer=' + this.getAtt + ']');
        this.$el = $(this.el);
    },

    show: function(t) {
        var me = this;
        this._element(t);

        if (!this.el) {
            console.log('%c error: data-full-layer element not found', 'background: #222; color: #bada55');
        }

        if (!this.el || !!this.el.style.display) return;

        // show transition
        this.el.classList.add('show');
        setTimeout(function() {
            me.el.classList.add('isAnimate');
        }, 50);

    },

    hide: function(t) {
        var me = this;
        this._element(t);

        this.el.classList.remove('isAnimate');
        setTimeout(function() {
            me.el.classList.remove('show');
        }, 100);
    }
}

/*********************************
 * Toast Popup
 *
 * @method SUI.Toast(t);
 * @param {String} t data-toast value
 *
 **********************************/
SUI.Toast = function(t) {
    var elem = document.querySelector('[data-toast=' + t + ']');
    var duration = 500,
        timer = elem.dataset.toastTimer - (duration * 2);

    $(elem).fadeIn(duration).delay(timer).fadeOut(duration);
}


/*********************************

 *
 * @method SUI.Accordion.init();
 *
 **********************************/
SUI.Accordion = {
    init: function() {
        this._for('[data-accordion]');
        this._for('[data-accordion-sub]');
    },

    _for: function(el) {
        var me = this;
        var elem = document.querySelectorAll(el);
        if (elem.length < 1) return;

        elem.forEach(function(acn) {
            me._buttonEach(acn);
        });
    },

    _buttonEach: function(acn) {
        var me = this;
        var menu, view;
        var accodion = acn.hasAttribute("data-accordion"),
            accodionSub = acn.hasAttribute("data-accordion-sub");

        if (accodion) {
            menu = "[data-acn-menu]", view = "[data-acn-view]";
        } else if (accodionSub) {
            menu = "[data-acn-submenu]", view = "[data-acn-subview]";
        }

        var button = acn.querySelectorAll(menu),
            content = acn.querySelectorAll(view);

        button.forEach(function(el, idx) {

            el.onclick = function(e) {
                e.preventDefault();
                var isMore = el.dataset.acnMenu || el.dataset.acnSubmenu;
                var onlyShow = acn.dataset.accordion || acn.dataset.accordionSub;
                var parent = el.closest('[data-accordion]');
                var isShow = false;
                if (onlyShow === 'onlyShow') {
                    isShow = true;
                }
                var element = content[idx];


                if (isMore === 'more') {
                    if (el.classList.contains('on')) {
                        el.classList.remove('on');
                        me._ContentEach(content, button, isShow, false);
                        return;
                    }
                    me._ContentEach(content, button, isShow, true);

                    content[idx].classList.add('on');
                    el.classList.add('on');
                    return;
                }

                // CASE : default accordion
                if (el.classList.contains('on') || element.offsetWidth > 0 && element.offsetHeight > 0) {
                    if (isShow) {
                        el.classList.remove('on');
                        content[idx].classList.remove('on');

                        var isVisible = el.parentElement.querySelectorAll(menu + '.on');
                        if (isVisible.length < 1) {
                            parent.classList.remove('on');
                        }

                        return;
                    }
                    parent.classList.remove('on');
                    el.classList.remove('on');
                    me._ContentEach(content, button, isShow, false);
                    return;
                }

                me._ContentEach(content, button, isShow, true);

                parent.classList.add('on');
                content[idx].classList.add('on');

                el.classList.add('on');
            };
        });
    },

    _ContentEach: function(content, button, isShow, state) {
        content.forEach(function(cont, i) {
            if (isShow) return;
            if (!state) {

                cont.classList.remove('on');
                return;
            }

            cont.classList.remove('on');
            button[i].classList.remove('on');
        });
    },
};

/*********************************

 *
 * @method SUI.Tab.init();
 *
 **********************************/
 SUI.Tab = {
    init: function() {
        var me = this;
        var tab = document.querySelectorAll('[data-tab]');
        if (tab.length < 1) return;

        tab.forEach(function(data) {
            var a = data.querySelectorAll('a, input[type="radio"]');
            a.forEach(function(el, idx) {
                var set = {
                    a: a,
                    data: data,
                    el: el,
                    idx: idx
                }
                me._eventHandler(set);
            });
        });
    },

    _eventHandler: function(set) {
        if (set.el.handler) {
            set.el.removeEventListener('click' , set.el.handler);
        }
        set.el.handler = function(e) {
            var value = set.data.dataset.tab;
            var isDatasetTop = set.data.hasAttribute('data-tab-scrolltop');
            var isLanding = set.el.hasAttribute('data-tab-landing');

            if (isLanding && Boolean(!set.el.closest('.brand_main_wrap'))) return false;

            if (value !== '') {
                var content = document.querySelectorAll('[data-tab-content=' + value + '] > div');
                if (!isLanding) {
                    content.forEach(function(cont, i) {
                        cont.style.display = 'none';
                        cont.classList.remove('on');
                    });
                }

                if (isDatasetTop) {
                    var contentParent = content[set.idx].parentElement;
                    var isLayerScroll = window.getComputedStyle(contentParent).overflow === 'auto';

                    isLayerScroll ? contentParent.scrollTo(0, 0) : window.scrollTo(0, 0);
                }

                if (!isLanding) {
                    content[set.idx].classList.add('on');
                    content[set.idx].style.display = 'block';
                }
            }

            for (var i = 0; i < set.a.length; i++) {
                set.a[i].closest('li').classList.remove('on');
            }
            set.el.closest('li').classList.add('on');
        };
        set.el.addEventListener('click' , set.el.handler);
    }
}


/*********************************

 *
 * @method SUI.CountDown.init();
 *
 **********************************/
SUI.CountDown = {
    init: function() {
        var me = this;
        var elem = document.querySelectorAll('[data-count-down]');

        if (elem.length < 1) return;

        elem.forEach(function(el) {
            var time = el.dataset.countDown;

            me._getTime(time, el);

            setInterval(function() {
                me._getTime(time, el);
            }, 1000);
        });
    },

    _getTime: function(t, el) {
        var eventDay = new Date(t.replace(/\s+/g, 'T').concat('.000+09:00'));
        var currDay = new Date(),
            endTime = eventDay / 1000,
            elapsed = currDay / 1000,
            totalSec = endTime - elapsed;

        var days = parseInt(totalSec / 86400),
            hours = parseInt(totalSec / 3600) % 24,
            min = parseInt(totalSec / 60) % 60,
            sec = parseInt(totalSec % 60, 10);

        var timeout = eventDay - currDay;

        if (timeout < 0) return;

        var hours = (hours < 10) ? '0' + hours : hours;
        var min = (min < 10) ? '0' + min : min;
        var sec = (sec < 10) ? '0' + sec : sec;

        el.textContent = hours + ' : ' + min + ' : ' + sec;
    }
}

/*********************************
 * Show Hide Layer
 *
 * @method SUI.LayerShow.init();
 * @method SUI.LayerShow.hide('target');
 * @param {String} target data-layer-view value
 *
 **********************************/
SUI.LayerShow = {
    init: function( clicker ) {
        var me = this;
        var layerShow = clicker == undefined ? document.querySelectorAll('[data-layer-show]') : clicker;

        if (layerShow.length < 1) return;

        layerShow.forEach(function(el) {
            var elDataset = el.dataset.layerShow;
            var element = {
                handler: el,
                layer: clicker == undefined ? document.querySelector('[data-layer-view=' + elDataset + ']') : el.nextElementSibling,
                posCheck: true,
            }

            me._handlerEvent(element);
        });
    },

    _handlerEvent: function(element) {
        var me = this;
        this.isAnimate = false;
        element.handler.addEventListener('click', function() {
            if (me.isAnimate) return;
            if (element.handler.classList.contains('on')) {
                me._insertClass('remove', element);
                return;
            }
            me._insertClass('add', element);
            return;
        });
    },

    _insertClass: function(s, element) {
        var me = this;
        var isTransition = element.layer.hasAttribute('data-layer-transition');
        var handler = element.handler,
            layer = element.layer;


        var animated = function() {
            me.isAnimate = false;
            layer.removeEventListener('transitionend', animated)
        }

        this.isAnimate = true;

        // CASE : add
        if (s === 'add') {

            handler.classList.add('on');
            layer.classList.add('on');

            if (handler.classList.contains('btn_tooltip')) {
                this._tooltip(element);
            }

            this._documentClose(element);

            if (isTransition) {
                setTimeout(function() {
                    layer.classList.add('isTransition');
                }, 30);
                layer.addEventListener('transitionend', animated)
            }
            return;
        }

        // CASE : remove
        if (isTransition) {
            var getDuration = $(layer).css('transition-duration');
            var sec = parseFloat(getDuration) * (/\ds$/.test(getDuration) ? 1000 : 1)

            layer.classList.remove('isTransition');
            handler.classList.remove('on');

            setTimeout(function() {
                layer.classList.remove('on');
                me._hasSelect(element);
                me.callback(element.layer);
                me.isAnimate = false;
            }, (sec / 2));
            return;
        }

        handler.classList.remove('on');
        layer.classList.remove('on');
        me._hasSelect(element);
        me.callback(element.layer);
        me.isAnimate = false;
    },


    _documentClose: function(element) {
        var me = this;

        var action = function(e) {
            // console.log(e.target)
            var datepicker = document.querySelector('.ui-datepicker');
            var datepickerContains = datepicker ? datepicker.contains(e.target) : false,
                datepickerPrev = e.target.classList.contains('ui-datepicker-prev'),
                datepickerNext = e.target.classList.contains('ui-datepicker-next'),
                datepickerButton = element.layer.querySelectorAll('.datepicker');

            var returnNode = e.target === element.handler || element.handler.contains(e.target);
            var returnDatepicker = e.target === datepicker || datepickerContains || datepickerPrev || datepickerNext;

            if (returnDatepicker) return;
            if (returnNode) return;

            if (e.target === element.layer.querySelector('[data-layer-hide]') || !element.layer.contains(e.target)) {
                me._insertClass('remove', element);
                document.removeEventListener('click', action);
                datepickerButton.length > 0 && me._datepicker(datepickerButton);
            }
        }
        document.addEventListener('click', action);
    },

    _datepicker: function(element){
        // datepickerButton.length > 0 && datepickerButton.datepicker('hide');
        element.forEach(function(elem, index){
            $(elem).datepicker('hide');
        })
    },

    _tooltip: function(element){
        if (element.posCheck) {
            var handler = element.handler,
                layer = element.layer,
                popup = handler.closest('.popup_inner');

            if (popup !== null) {
                // Tooltip in Popup
                var popupWidth = parseInt(getComputedStyle(handler.closest('.popup_inner')).width),
                    layerWidth = parseInt(getComputedStyle(layer).width),
                    wLeft = (window.innerWidth - popupWidth) / 2,
                    pLeft = Math.round(handler.getBoundingClientRect().left) - wLeft,
                    pRight = popupWidth - (Math.round(handler.getBoundingClientRect().right) - wLeft),
                    total = 'auto';

                if (pLeft >= pRight) {
                    // Handler position : right
                    if (pRight > (layerWidth / 2.5)) {
                        total = pRight / 2;
                        layer.style.left = '-' + total + 'px';
                    } else {
                        layer.style.cssText = 'left:auto; right:-10px;';
                    }
                }
            } else {
                // Tooltip in PC(Document)
                if (Math.round(handler.getBoundingClientRect().left) >= window.innerWidth * 0.8) {
                    layer.style.cssText = 'left:auto; right:-10px;';
                }
            }

            element.posCheck = false;
        }
    },

    _hasSelect: function(element) {
        if (element.layer.querySelectorAll('[data-selectbox]').length > 0) {
            SUI.SelectBox.reset(element.layer);
        }
    },

    hide: function(target) {
        var element = {
            handler: document.querySelector('[data-layer-show=' + target + ']'),
            layer: document.querySelector('[data-layer-view=' + target + ']'),
        }
        this._insertClass('remove', element);
    },

    callback: function(e) {},
}
/*********************************
 * GNB Global Navigation
 *
 * @method SUI.GlobalNavi.init();
 *
 **********************************/
SUI.GlobalNavi = {
    init: function() {
        this.menu = document.querySelectorAll('[data-global-menu]');

        if (this.menu.length < 1) return;

        this._menuGlobal();
        this._menuCategory();
    },

    // GNB MENU
    _menuGlobal: function() {
        var me = this;
        this.menu.forEach(function(menu) {
            menu.addEventListener('mouseenter', me._mouseenterGlobal);
        });
    },

    // GNB MENU mouseenter event
    _mouseenterGlobal: function(e) {
        var menu = e.target;
        var dataset = menu.dataset.globalMenu;
        var layer = document.querySelector('[data-global-' + dataset + ']');

        var _removeClass = function() {
            for (var i = 0; i < SUI.GlobalNavi.menu.length; i++) {
                SUI.GlobalNavi.menu[i].parentElement.classList.remove('on');
            }
            var hasON = layer.querySelectorAll('.on');
            for (var i = 0; i < hasON.length; i++) {
                if (!hasON[i].closest('.category_select')) {
                    hasON[i].classList.remove('on');
                }
            }
        }
        _removeClass();

        // layer show
        menu.parentElement.classList.add('on');
        layer.classList.add('on');

        // mouseout event
        var check = {
            menu: menu,
            layer: layer
        }
        SUI.GlobalNavi._mouseleaveAction(check, function() {
            _removeClass();
            layer.classList.remove('on');
        });
    },

    // category mouseenter event
    _menuCategory: function() {
        var me = this;
        var first = document.querySelector('[data-depth-first]');

        if (!!!first) return;

        var firstLink = first.querySelectorAll('a');
        this.group = document.querySelectorAll('[data-depth-group]');


        firstLink.forEach(function(a, i) {
            a.addEventListener('mouseenter', function(e) {
                var set = {
                    depth: document.querySelector('[data-depth="' + (i + 1) + '"]')
                }
                me._mouseenterCategory(firstLink, e.target, set);
            });
        });

        this.group.forEach(function(el, idx) {
            var depth = el.querySelectorAll('[data-depth]');

            depth.forEach(function(depth) {
                var groupLink = depth.querySelectorAll('a');

                groupLink.forEach(function(a, i) {
                    a.addEventListener('mouseenter', function(e) {
                        var firstIndex = a.closest('[data-depth]').dataset.depth;
                        var set = {
                            depth: document.querySelector('[data-depth="' + firstIndex + '_' + (i + 1) + '"]'),
                            idx: idx,
                        }
                        me._mouseenterCategory(groupLink, e.target, set);

                    });
                });

            });

        })

    },

    _mouseenterCategory: function(elem, target, set) {
        var category = target.parentElement.parentElement.hasAttribute('data-depth-first');

        for (var i = 0; i < elem.length; i++) {
            elem[i].parentElement.classList.remove('on');
        }
        target.parentElement.classList.add('on');

        target.closest('.category_wrap').querySelectorAll('[data-depth-group]').forEach(function( el ){
            el.classList.remove('is-last');
        })

        if (category) {
            this.group.forEach(function(el) {
                el.classList.remove('on');
                var hasON = el.querySelectorAll('.on');
                hasON.forEach(function(el) {
                    el.classList.remove('on');
                });
            });

        } else {
            for (var n = set.idx; n < this.group.length; n++) {
                if (set.idx < n) {
                    this.group[n].classList.remove('on');
                    var hasON = this.group[n].querySelectorAll('.on');
                    hasON.forEach(function(el) {
                        el.classList.remove('on');
                    });
                }
            }
        }

        if (set.depth) {
            var depthParent = set.depth.parentElement;
            var depthAll = depthParent.querySelectorAll('[data-depth]');

            depthAll.forEach(function(el) {
                el.classList.remove('on');
            });

            depthParent.classList.add('on');
            set.depth.classList.add('on');
        }

        if (set.depth == null) {
            target.parentElement.closest('.depth_group').classList.add('is-last')
        }

    },

    _mouseleaveAction: function(check, fn) {
        var _removeAction = function(e) {
            if (check.menu === e.target || check.menu.contains(e.target) || check.layer.contains(e.target)) {
                return;
            }
            fn();
            document.removeEventListener('mouseover', _removeAction);
        }
        document.addEventListener('mouseover', _removeAction);
    }
}

/*********************************

 *
 * @method SUI.BrandKeyword.init();
 *
 **********************************/
SUI.BrandKeyword = {
    init: function() {
        var me = this;
        this.brand = document.querySelectorAll('[data-keyword-brand]');

        if (this.brand.length < 1) return;

        this.isScroll = false;

        this.brand.forEach(function(el) {
            var brandList = el.querySelector('.category_index_all');
            var navigator = el.querySelector('.category_index_group');
            var ul = brandList.querySelector('ul');
            //var li = ul.querySelectorAll(':scope > li'); // IE11 not support scope
            var li = Array.prototype.slice.call(el.querySelectorAll('.category_index_all > ul > li')).filter(function(value){
                if (value.style.display != 'none') return value;
            });

            var elements = {
                brand: {
                    wrap: brandList,
                    ul: ul,
                    li: li,
                },
                navigator: navigator
            }

            me._handlerEvent(elements);
            me._scrollEvent(elements);
        });
    },

    // navigator handler event
    _handlerEvent: function(el) {
        var me = this;
        var brand = el.brand.wrap,
            li = el.brand.li,
            navigator = el.navigator;
        // var a = navigator.querySelectorAll('a');
        var a = Array.prototype.slice.call(navigator.querySelectorAll('a')).filter(function(value){
            if (value.closest('li').style.display != 'none') return value;
        });

        a.forEach(function(button, idx) {
            // right navigator event
            button.addEventListener('click', function(e) {
                try {
                    $(brand).stop().animate({
                        scrollTop: li[idx].offsetTop
                    }, 0);
                    me._navigatorPos(navigator);
                } catch (e) {
                    console.log(e);
                }
            });
        });
    },

    // navigator scroll pos
    _navigatorPos: function(navigator) {
        var h = navigator.clientHeight / 2;
        var ul = navigator.querySelector('ul');
        var li = navigator.querySelector('.active');

        var max = ul.scrollHeight - navigator.clientHeight;
        var y = Math.round(li.offsetTop - ul.offsetTop - h + li.clientHeight / 3);

        if (y < 0) {
            y = 0;
        } else if (y > max) {
            y = max;
        }
        //keywordScroll.scrollTo({top:y, left:0, behavior:'smooth'}); // IOS not working smooth
        $(navigator).stop().animate({
            scrollTop: y
        }, 300);
    },

    // brand list scroll
    _scrollEvent: function(el) {
        var me = this;
        var brand = el.brand.wrap,
            li = el.brand.li,
            navigator = el.navigator;
        var handler;

        var _removeClass = function() {
            // handler = navigator.querySelectorAll('li');
            handler = Array.prototype.slice.call(navigator.querySelectorAll('li')).filter(function(value){
                if (value.closest('li').style.display != 'none') return value;
            });
            handler.forEach(function(all) {
                all.classList.remove('active');
            });
        }
        // brand list scroll event
        SUI.Utils.ScrollListener(brand, function() {
            try {
                li.forEach(function(el, idx) {
                    var offsetTop = el.offsetTop;

                    if (brand.scrollTop > offsetTop - 10) {
                        _removeClass();
                        handler[idx].classList.add('active');

                        me._navigatorPos(navigator);
                    }
                });
            } catch (e) {
                console.log(e);
            }
        });
    }
}

/*********************************

 *
 * @method SUI.Anchor.init();
 *
 **********************************/
SUI.Anchor = {
    init: function() {
        this.anchor = document.querySelector('[data-anchor]');
        this.load = true;
        this.scroll = true;

        if (!this.anchor) return;

        this._handlerEvent();
        this._bindEvent();
    },

    _handlerEvent: function() {
        var me = this;
        this.handler = this.anchor.querySelectorAll('a');
        this.handler.forEach(function(button) {
            button.addEventListener('click', function(e) {
                try {
                    e.preventDefault();


                    document.removeEventListener('scroll', document['requestAF_Anchor']);
                    me.scroll = true;

                    var name = button.getAttribute('href').split("#");
                    var top = window.pageYOffset + document.getElementById(name[1]).getBoundingClientRect().top;
                    var move = top - me.anchor.parentElement.offsetHeight + 10;
                    var navList = me.anchor.querySelectorAll('li');

                    navList.forEach(function(link) {
                        link.classList.remove('on');
                    });
                    e.currentTarget.closest('li').classList.add('on');

                    //window.scrollTo({top:move, left:0, behavior:'smooth'}); // IOS not working smooth
                    $('html, body').stop().animate({
                        scrollTop: move
                    }, 600, function(){
                        me._bindEvent();
                    });
                } catch (e) {
                    console.log(e);
                }

            });
        });
    },

    _bindEvent: function() {
        var me = this;
        var anchorArea = document.querySelectorAll('[data-anchor-area]');
        var _sectionEvent = function() {
            for (var i = 0; i < anchorArea.length; i++) {
                var element = anchorArea[i];
                var top = element.offsetTop;
                var bottom = top + element.clientHeight;
                var scrollTop = SUI.Utils.ScrollTop();

                if (top < scrollTop && bottom > scrollTop) {
                    var navList = me.anchor.querySelectorAll('li');
                    navList.forEach(function(link) {
                        link.classList.remove('on');
                        navList[i].classList.add('on');
                    })
                    return false;
                }
            }
        }

        if ( this.load ) {
            SUI.Utils.loadFn(_sectionEvent);
            this.load = false;
        }

        // scroll event
        if ( this.scroll ) {
            SUI.Utils.ScrollListener(document, _sectionEvent, 'Anchor');
            this.scroll = false;
        }
    },
}

/*********************************
 * SIDE QUICK
 * @method SUI.Side.init();

 * @param {String} t target className
 *
 **********************************/
SUI.Side = {
    init: function() {
        this.wrap = document.querySelector('[data-quick-wrap]');
        this._scrollEvent();
    },

    quick: function(t, e) {
        var content = document.querySelector('[data-quick-content]');
        this.inner = content.querySelectorAll('[data-quick-content] > .inner');
        var target = content.querySelector('.quick_' + t);
        this.menu = this.wrap.querySelectorAll('.menu li');
        var elem = document.querySelector('.' + e).parentElement;

        if (elem.classList.contains('on')) {
            elem.classList.remove('on');
            target.classList.remove('on');
        } else {
            this._removeClass();
            elem.classList.add('on');
            target.classList.add('on');
        }

        this._caseEvent(t);

        if (!this.wrap.classList.contains('on')) {
            this._sideToggle(true);
        }
    },

    _caseEvent: function(t) {
        if (t === 'event') {
            SUI.Slider.quickEvent(); // event swiper destory & reinit
        }

        if (t === 'history') {
            SUI.Interaction.textRoliing(true); // true is setInterval start
        } else {
            SUI.Interaction.textRoliing(false); // false is setInterval clear
        }
    },

    _removeClass: function() {
        for (var i = 0; i < this.inner.length; i++) {
            this.inner[i].classList.remove('on');
            this.menu[i].classList.remove('on');
        }
    },

    _scrollEvent: function() {
        if (!this.wrap) return;
        var me = this;
        var scroll = 0;
        SUI.Utils.ScrollListener(document, function() {
            var st = SUI.Utils.ScrollTop();
            if (st > scroll) {
                me.wrap.classList.add('down');
            } else if (st < scroll) {
                me.wrap.classList.remove('down');
            }
            scroll = st <= 0 ? 0 : st;
        });
    },

    _sideToggle: function(s) {
        if (s) {
            return this.wrap.classList.add('on');
        }
        this.wrap.classList.remove('on');
    },

    close: function() {
        SUI.Interaction.textRoliing(false);
        this._sideToggle(false);
        this._removeClass();
    }
}


/*********************************

 *
 * @method SUI.SelectBox.init();

 * @param {Element} target is document.querySelector('.element');
 *
 **********************************/
SUI.SelectBox = {
    init: function() {
        var me = this;
        var selectbox = document.querySelectorAll('[data-selectbox]');

        if (selectbox.length < 1) return;

        selectbox.forEach(function(el) {
            var data = {
                wrap: el,
                selected: el.querySelector("[data-selected]"),
                size: (el.hasAttribute("data-set-size")) ? el.dataset.setSize : null,
                button: el.querySelector('[data-set-button]'),
                list: el.querySelector("[data-set-list]"),
                option: el.querySelectorAll("[data-set-list] a"),
            }
            me._set(data);
            me._selected(data);
            me._handlerButton(data);
            me._handlerOption(data);
        });
    },

    reset: function(target) {
        var setButton = target.querySelectorAll("[data-set-button]");
        var selected = target.querySelectorAll("[data-selected]");
        for (var i = 0; i < selected.length; i++) {
            selected[i].removeAttribute('data-selected');
        }

        setButton.forEach(function(el) {
            var text = el.dataset.setButton;
            if (text !== '') {
                el.textContent = text;
            }
            el.classList.remove('on');
        });
    },
    // data-set-size="100px"
    _set: function(d) {
        if (!!d.size) {
            d.wrap.style.cssText = 'width:' + d.size;
        }
    },
    // pageload has data-selected
    _selected: function(d) {
        if (d.selected) {
            var a = d.selected.querySelector('a');
            var hasValue = a.querySelector('.value');
            var value = hasValue ? hasValue.textContent : a.textContent;
            d.selected.classList.add('on');
            this._selectAction(d, value);
        }
    },
    // option select active
    _selectAction: function(d, value) {
        d.button.innerHTML = '<i>' + value + '</i>';
        d.button.classList.add('on');
        d.wrap.classList.remove('on');
    },
    // select open handler
    _handlerButton: function(d) {
        var me = this;
        d.button.addEventListener('click', function() {
            if (d.wrap.classList.contains('on')) return;
            d.wrap.classList.add('on');

            setTimeout(function() {
                me._documentClose(d);
            })
        });
    },
    // select option handler
    _handlerOption: function(d) {
        var me = this;
        d.option.forEach(function(el) {
            el.addEventListener('click', function(e) {
                var hasValue = el.querySelector('.value');
                var value = hasValue ? hasValue.textContent : e.target.textContent;

                me._selectAction(d, value);

                for (var i = 0; i < d.option.length; i++) {
                    d.option[i].parentElement.removeAttribute('data-selected');
                }

                e.target.parentElement.setAttribute('data-selected', '');
            });
        });
    },

    _documentClose: function(d) {
        var action = function(e) {
            d.wrap.classList.remove('on');
            document.removeEventListener('click', action);
        }
        document.addEventListener('click', action);
    }
}

/*********************************

 *
 * @method SUI.Sticky.init();
 *
 **********************************/
SUI.Sticky = {
    init: function() {
        this.navi = document.querySelector('[data-sticky-navi]');
        if (!this.navi) return;

        this._bindEvent();
    },

    _bindEvent: function() {
        var me = this;
        var naviTop = this.navi.offsetTop + 30;

        var _sectionEvent = function() {
            var parentOffset = $('#header').offset().top;
            var top = naviTop + parentOffset;
            var st = SUI.Utils.ScrollTop();

            if (st > top) {
                me.navi.parentElement.classList.add('fixed');
            } else {
                me.navi.parentElement.classList.remove('fixed');
            }
        }

        SUI.Utils.loadFn(_sectionEvent);
        // scroll event
        SUI.Utils.ScrollListener(document, _sectionEvent);
    }
}

/*********************************

 *
 * @method SUI.Category.filter();
 *
 **********************************/
SUI.Category = {
    filter: function() {
        var me = this;
        var filterCategory = document.querySelector('[data-category-filter]');

        if (!filterCategory) return;

        var menu = filterCategory.querySelectorAll('[data-filter-menu]');
        var submenu = filterCategory.querySelectorAll('[data-filter-depth] a');

        menu.forEach(function(el) {
            me._handlerMenu(el);
        });
        submenu.forEach(function(el) {
            me._handlerSubmenu(el);
        });
    },

    _handlerMenu: function(el) {
        el.addEventListener('click', function() {
            var target = el.closest('li');
            if (target.classList.contains('on')) {
                return target.classList.remove('on');
            }
            target.classList.add('on');
        }, false);
    },

    _handlerSubmenu: function(el) {
        el.addEventListener('click', function() {
            var target = el.closest('li');
            if (target.classList.contains('on')) {
                return target.classList.remove('on');
            }
            target.classList.add('on');
        }, false);
    },
}
/*********************************

 *
 * @method SUI.Product.init();
 *
 **********************************/
SUI.Product = {
    init: function() {
        this._detailViewMore();
        this._filterSticky();
        this._stickyContent();
        this._zoomInit();
    },


    _detailViewMore: function() {
        var detail = document.querySelector('.product_detail_group .product_detail_info');

        if (!!!detail) return;

        var box = detail.querySelector('.detail_info'),
            button = detail.querySelector('.btn_toggle');

        if (!!!button) return;

        button.addEventListener('click', function(e) {
            button.classList.toggle('on');
            box.classList.toggle('on');
        });
    },

    // filterSearch Height Setting
    _filterSticky : function(){
        var sticky = document.querySelectorAll('[data-sticky-content="filter"]');

        if (sticky.length < 1) return;
        sticky.forEach(function(el) {
            var totalHeight, contHeight;
            var _useFnc = function(){
                contHeight = el.nextElementSibling.offsetHeight;
                var header = document.querySelector('.header_wrap');
                if(contHeight > window.innerHeight || (header.classList.contains('fixed') && contHeight > window.innerHeight)) {
                    totalHeight = window.innerHeight - document.querySelector('.filter_category').getBoundingClientRect().top;
                } else {
                    totalHeight = 500;
                }
                el.style.height = totalHeight + 'px';
            }
            _useFnc();

            if (el.dataset.loaded === undefined) {
                el.dataset.loaded = true;
                SUI.Utils.ScrollListener(document, _useFnc);
            }
        });
    },

    // contents middle sticky
    _stickyContent: function() {
        var stickyTab = document.querySelectorAll('[data-sticky-content]');
        var naviHeight = 70;

        if (stickyTab.length < 1) return;

        var container = document.querySelector('#container');

        stickyTab.forEach(function(el) {
            var firstParent = stickyTab[0].parentElement;
            var tabTop = (firstParent.offsetParent.offsetTop - naviHeight);
            var dataset = el.dataset.stickyContent;
            var padding = parseInt(window.getComputedStyle(container).paddingBottom);

            var _sideSticky = function() {

                var footer = document.querySelector('#footer');
                var footerTop = footer ? footer.offsetTop : 0;
                var screenH = window.innerHeight;
                var scrollBarH = screenH - $(window).height();
                var option = dataset === 'option';
                var filter = dataset === 'filter';

                if (option || filter) {
                    var st = SUI.Utils.ScrollTop();

                    // viewport in footer - fixed element bottom
                    if (st > (footerTop - padding) - screenH && el.classList.contains('fixed')) {
                        var num = padding + st - (footerTop - screenH);

                        el.classList.add('bottom');
                        el.style.bottom = num + 'px';
                    } else {
                        el.classList.remove('bottom');
                        el.style.bottom = 'auto';
                    }
                    // fixed element horizontal move
                    if (el.classList.contains('fixed')) {
                        el.style.marginLeft = '-' + document.documentElement.scrollLeft + 'px';
                    }
                }

                if (option) {
                    var height = screenH - stickyTab[0].offsetHeight - scrollBarH - 10;
                    el.style.height = height + 'px'; // resize
                }

                if (filter) {
                    var rect = el.getBoundingClientRect().top;
                    var top = rect <= 110 ? 110 : rect;
                    var height = (screenH - top) - scrollBarH;
                    var maxH = height > firstParent.clientHeight ? firstParent.clientHeight : height;
                    el.style.height = height <= 400 ? 400 : maxH + 'px'; // resize
                }
            }

            var _sectionEvent = function() {
                var changeTop = tabTop + firstParent.offsetTop - (dataset === 'filter' ? naviHeight + 40 : 0);
                var st = SUI.Utils.ScrollTop();
                var scrollY = st - changeTop;
                var translateY = 'transform:translateY(-' + scrollY + 'px);';

                // add fixed
                if (st > (changeTop + naviHeight)) {
                    el.classList.add('fixed');

                    if (dataset !== 'filter') {
                        SUI.Sticky.navi ? SUI.Sticky.navi.style.cssText = translateY : null;
                    }
                } else {
                    if (!el.classList.contains('bottom')) {
                        el.classList.remove('fixed');
                    }
                    if (dataset !== 'filter') {
                        SUI.Sticky.navi ? SUI.Sticky.navi.style.cssText = translateY : null;
                    }
                }

                _sideSticky();
            }

            if (dataset !== 'filter') {
                window.addEventListener("resize", SUI.Utils.RequestAF(function() {
                    _sideSticky();
                }, false));

                SUI.Utils.loadFn(_sectionEvent);
                // scroll event
                SUI.Utils.ScrollListener(document, _sectionEvent);
            }
        });
    },

    // product detail image Zoom view -  w3schools image zoom JS customizing
    _zoomInit: function() {
        this.zoomImage = document.querySelector('[data-zoom-image]')
        this.zoomTarget = document.querySelector('[data-zoom-target]');
        this.zoomView = document.querySelector('[data-zoom-view]');
        this.zoomThum = document.querySelector('[data-zoom-thumb]');

        if (!!!this.zoomImage) return;

        this._zoomMouseEvent();
        this._zoomThum();
    },

    _zoomMouseEvent: function() {
        var me = this;
        this.zoomTarget.addEventListener("mouseenter", function(e) {
            e.target.parentElement.classList.add('on');

            me._zoom();

            var hide = function(e) {
                if (me.zoomImage.contains(e.target)) {
                    return;
                }
                me.zoomImage.classList.remove('on');
                document.removeEventListener("mouseover", hide);
            }

            document.addEventListener("mouseover", hide);
        });
    },

    _zoom: function() {
        var img, lens, result, cx, cy;

        img = this.zoomTarget;
        result = this.zoomView;

        var isPointer = document.querySelector('.zoom_pointer');
        if (isPointer) {
            lens = isPointer;
        } else {
            lens = document.createElement("div");
            lens.setAttribute("class", "zoom_pointer");

            img.parentElement.insertBefore(lens, img);
        }

        cx = result.offsetWidth / lens.offsetWidth;
        cy = result.offsetHeight / lens.offsetHeight;

        result.style.backgroundImage = "url('" + img.src + "')";
        result.style.backgroundSize = (img.width * cx) + "px " + (img.height * cy) + "px";

        lens.addEventListener("mousemove", moveLens);
        img.addEventListener("mousemove", moveLens);

        lens.addEventListener("touchmove", moveLens);
        img.addEventListener("touchmove", moveLens);

        function moveLens(e) {
            var pos, x, y;
            e.preventDefault();
            pos = getCursorPos(e);

            x = pos.x - (lens.offsetWidth / 2);
            y = pos.y - (lens.offsetHeight / 2);

            if (x > img.width - lens.offsetWidth) x = img.width - lens.offsetWidth;
            if (x < 0) x = 0;
            if (y > img.height - lens.offsetHeight) y = img.height - lens.offsetHeight;
            if (y < 0) y = 0;


            lens.style.left = x + "px";
            lens.style.top = y + "px";

            result.style.backgroundPosition = "-" + (x * cx) + "px -" + (y * cy) + "px";
        }

        function getCursorPos(e) {
            var a, x = 0,
                y = 0;
            e = e || window.event;

            a = img.getBoundingClientRect();

            x = e.pageX - a.left;
            y = e.pageY - a.top;

            x = x - window.pageXOffset;
            y = y - window.pageYOffset;
            return {
                x: x,
                y: y
            };
        }
    },

    _zoomThum: function() {
        if (!!!this.zoomThum) return;

        var me = this;
        var a = this.zoomThum.querySelectorAll('a');

        a.forEach(function(el) {
            el.addEventListener('click', function(e) {

                var dataImage = el.hasAttribute('data-image') && el.dataset.image !== '';
                var src = el.querySelector('img').src;
                a.forEach(function(el) {
                    el.parentElement.classList.remove('on');
                });
                el.parentElement.classList.add('on');
                me.zoomTarget.src = dataImage ? el.dataset.image : src;
                me.zoomTarget.onerror = function() {
                    this.onerror = null;
                    me.zoomTarget.src = src
                };
            });
        });

    }
}

/*********************************

 *
 * @method SUI.Payment.init();
 *
 **********************************/
SUI.Payment = {
    dataChosen: '[data-payment-chosen]',
    dataSelect: '[data-payment-select]',
    dataList: '[data-paylist]',
    box: '.order_payment_box',
    paymeans: '.order_paymeans',

    init: function() {
        this._select();
        this._payList();
    },

    _select: function() {
        var me = this;
        var paymentSelect = document.querySelectorAll(this.dataSelect);
        if (paymentSelect.length < 1) return;

        var label = document.querySelector(this.dataChosen).querySelectorAll('label');

        label.forEach(function(el, index) {
            el.addEventListener('click', function() {
                var current = paymentSelect[index];

                for (var i = 0; i < paymentSelect.length; i++) {
                    paymentSelect[i].classList.remove('on');
                }

                current.classList.add('on');


                if (current.querySelector(me.dataList)) {
                    var input = current.querySelector(me.dataList).closest('.order_paylist').querySelectorAll('input');
                    var paymeans = document.querySelectorAll(me.paymeans);

                    for (var i = 0; i < input.length; i++) {
                        input[i].checked = false;
                    }

                    for (var i = 0; i < paymeans.length; i++) {
                        paymeans[i].classList.remove('on');
                    }
                }
            });
        })
    },

    _payList: function() {
        var me = this;
        var paymentList = document.querySelectorAll(this.dataList);

        if (paymentList.length < 1) return;

        paymentList.forEach(function(el) {
            var label = el.querySelector('label');
            var viewAll = document.querySelectorAll(me.paymeans);

            label.addEventListener('click', function(e) {
                var dataset = e.target.closest('li').dataset.paylist;

                viewAll.forEach(function(el) {
                    el.classList.remove('on');
                })

                if (dataset !== '') {
                    var view = document.querySelector(me.paymeans + '.' + dataset);
                    if (!!!view) return;
                    view.classList.add('on');
                }
            });
        })
    }
}

/*********************************
 * Interaction Animate
 *
 * @method SUI.Interaction.init();
 *
 **********************************/
SUI.Interaction = {
    init: function() {
        this.textRoliing();
    },

    cart: function() {
        var btnCart = document.querySelector('.btn_cart'),
            cart = btnCart.querySelector('.blind');

        if (!btnCart.classList.contains('in')) btnCart.classList.add('in');

        btnCart.classList.add('animated');

        var endReset = function() {
            btnCart.classList.remove('animated');
            cart.removeEventListener('animationend', endReset);
        }
        cart.addEventListener('animationend', endReset);
    },

    textRoliing: function() {
        var elem = document.querySelector('[data-interaction="textRolling"]');

        if (!!!elem) return;


        if (elem.closest('.quick_cont') && typeof arguments[0] === 'undefined') {
            return;
        }

        this.timer;
        var idx = 0;
        var prevIdx;

        if (arguments[0] === false) {
            return clearInterval(this.timer);
        }

        var list = elem.querySelectorAll('.p_list');
        var length = list.length;

        list.forEach(function(el) {
            el.classList.remove('on');
            list[0].classList.add('on');
        });

        clearInterval(this.timer);

        this.timer = setInterval(function() {
            prevIdx = idx;
            idx++;

            if (idx >= length) {
                idx = 0;
            }
            list[prevIdx].classList.remove('on');
            list[idx].classList.add('on');
        }, 5200);

    },
}


/*********************************
 * video IntersectionObserver
 *
 * @method SUI.Video.observer();
 *
 **********************************/
SUI.Video = {
    observer: function() {
        var videoPlayer = document.querySelectorAll('[data-video-observer]');

        if (videoPlayer.length < 1) return;

        var observer = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                var youtube = entry.target.dataset.videoObserver === 'youtube';
                //console.log(entry.intersectionRatio)
                if (entry.intersectionRatio > 0.9) {
                    if (youtube) {
                        return entry.target.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
                    }
                    entry.target.play();
                } else {
                    if (youtube) {
                        return entry.target.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
                    }
                    entry.target.pause();
                }
            });
        }, {
            root: null,
            rootMargin: '0px 0px 0px 0px',
            threshold: 0.9,
        });

        videoPlayer.forEach(function(el) {
            observer.observe(el);
        })
    },
}



/*********************************

 *
 * @method SUI.Vchat.init();
 *
 **********************************/
SUI.Vchat = {
    elem: document.querySelector('[data-vhcat]'),
    init: function() {
        if (!this.elem) return;
        this.text = this.elem.querySelector('[data-vhcat-text]');
        setTimeout(this._bindEvent.bind(this), 300);
        this.text.style.width = this.text.offsetWidth + 'px';
    },

    _bindEvent: function() {
        var me = this;
        var prevTop = SUI.Utils.ScrollTop();

        var _sectionEvent = function() {
            var st = SUI.Utils.ScrollTop() + 10;
            if (st !== prevTop) {
                me.elem.classList.add('active');
            }
        }

        // scroll event
        SUI.Utils.ScrollListener(document, _sectionEvent, 'Vchat', {
            once: true
        });
    }
}



/*********************************

 *
 * @method SUI.ToggleBox.init();
 *
 **********************************/
SUI.ToggleBox = {
    init: function() {
        var me = this;
        var elem = document.querySelectorAll('[data-toggle-box]');
        if(!elem.length) return;

        elem.forEach(function(el) {
            me._bindEvent(el);
        });
    },

    _bindEvent: function(el) {
        var me = this;

        if(el.handler) {
            el.removeEventListener('change', el.handler);
        }
        el.handler = function() {
            var togglBox = document.getElementById(this.dataset.toggleBox);
            togglBox.classList.toggle('is-hide');
            if (!togglBox.classList.contains('is-hide')) {
                togglBox.querySelector('button').focus();
            }
        };
        el.addEventListener('change', el.handler);
    }
}



/*********************************

 *
 * @method SUI.CouponBrand.init();
 *
 **********************************/
SUI.CouponBrand = {
    init: function() {
        var me = this;
        this.brand = document.querySelectorAll('[data-coupon-brand]');

        if (this.brand.length < 1) return;

        this.isScroll = false;

        this.brand.forEach(function(el) {
            var brandList = el.querySelector('.scroll_custom');
            var navigator = el.querySelector('.choice_list');
            //var li = ul.querySelectorAll(':scope > li'); // IE11 not support scope
            var li = el.querySelectorAll('.scroll_custom .order_brand_list');

            var elements = {
                brand: {
                    wrap: brandList,
                    li: li,
                },
                navigator: navigator
            }

            me._handlerEvent(elements);
        });
    },

    // navigator handler event
    _handlerEvent: function(el) {
        var me = this;
        var brand = el.brand.wrap,
            li = el.brand.li,
            navigator = el.navigator;
        var a = navigator.querySelectorAll('a');

        a.forEach(function(button, idx) {
            // top navigator event
            if(button.handler) {
                button.removeEventListener('click', button.handler);
            }
            button.handler = function(e) {
                e.preventDefault();
                var target = brand.querySelector(this.hash);
                try {
                    $(brand).stop(true).animate({
                        scrollTop: target.offsetTop
                    }, 300);
                    me._navigatorActive(this, navigator);
                } catch (e) {
                    // console.log(e);
                }
            };
            button.addEventListener('click', button.handler);

        });
    },

    // navigator active class
    _navigatorActive: function(target, navigator) {
        navigator.querySelectorAll('a.on').forEach(function(e) {
            e.classList.remove('on');
        });
        target.classList.add('on');
    },
}



/*********************************

 *
 * @method SUI.Breadcrumb.init();
 *
 **********************************/
SUI.Breadcrumb = {
    init: function() {
        var box = Array.prototype.slice.call(document.querySelectorAll('.breadcrumb_box'));
        var anchor = box.map(function( el ){
            return el.previousElementSibling;
        });

        SUI.LayerShow.init( anchor );
    },
}



/*********************************

 *
 * @method SUI.BrandMore.init();
 *
**********************************/
SUI.BrandMore = {
    init: function() {
        this.brand = document.querySelector('.brand_more .desc_text');
        if (!this.brand) return false;

        if (this.brand.clientWidth <= this.brand.closest('.accordion_desc').clientWidth) {
            this.brand.closest('.brand_more').classList.remove('is-more');
        } else {
            this.brand.closest('.brand_more').classList.add('is-more');
        }
    },
}



/*********************************

 *
 * @method SUI.Theme.init();
 *
**********************************/
SUI.Theme = {
    init: function() {
        this.tooltip(); // 툴팁
        this.more(); // 더보기
    },
    tooltip : function(){
        var selector = '[data-theme="tooltip"]';
        var caller = document.querySelector( selector );
        if (!caller) return false;

        var close = caller.querySelector('[data-theme="tooltip:close"]');

        SUI.Utils.overlap(close, 'click', function(e) {
            e.preventDefault();
            var tooltip = this.closest( selector );
            try {
                $(tooltip).fadeOut(400, function(){
                    tooltip.classList.remove('on');
                });
            } catch (e) {
                // console.log(e);
            }
        });
    },
    more: function() {
        var selector = '[data-theme="more"]';
        var caller = document.querySelectorAll( selector );
        if (!caller.length) return false;

        caller.forEach(function(el, idx){
            var button = el.querySelector('.btn_toggle_more'), list = el.querySelector('.brand_sel_list');
            if (list.querySelectorAll('li').length > 12) {

                button.closest('.btn_wrap').style.display = 'block';

                SUI.Utils.overlap(button, 'click', function(e) {
                    e.preventDefault();
                    this.classList.toggle('on');
                    list.classList.toggle('on');
                });
            }
        })
    }
}



/*********************************

 *
 * @method SUI.Agree.init();
 *
**********************************/
SUI.Agree = {
    init () {
        var agree = document.querySelectorAll('[data-agree]');
        if ( agree.length < 1 ) return;

        agree.forEach((el, idx) => {
            var set = {
                el : el,
                all : el.querySelector('[data-agree-all]'),
                items : el.querySelectorAll('[data-agree-item]'),
                button : el.querySelector('[data-agree-button]'),
                total : false,
            }
            this._eventHandler(set);
        });
    },

    _eventHandler (set) {
        var self = this;

        if (set.all) {
            SUI.Utils.overlap(set.all, 'change', function(e) {
                self._stateObserver(set, 'all');
            });
        }

        set.items.forEach(el => {
            SUI.Utils.overlap(el, 'change', function(e) {
                self._stateObserver(set, 'items');
            });
        });
    },

    _stateObserver ( set, field ) {
        if (field === 'all') {
            set.items.forEach(el => {
                el.checked = set.all.checked;
            });
            set.total = set.all.checked;
        } else {
            var checked = [...set.items].filter( item => item.checked == true);

            set.total = set.items.length === checked.length;
            if (set.all) set.all.checked = set.total;
        }
        set.button.disabled = !set.total;
    }
}


$(document).ready(function() {
    if ($("[data-original]").length > 0) {
        $("[data-original]").lazyload();
    }
    SUI.GlobalNavi.init();
    SUI.Video.observer();
    SUI.Sticky.init();
    SUI.SelectBox.init();
    SUI.Accordion.init();
    SUI.CountDown.init();
    SUI.Tab.init();
    SUI.LayerShow.init();
    SUI.BrandKeyword.init();
    SUI.Category.filter();
    SUI.Anchor.init();
    SUI.Product.init();
    SUI.Side.init();
    SUI.Payment.init();
    SUI.Interaction.init();
    SUI.ToggleBox.init(); 
    SUI.CouponBrand.init(); 
    SUI.Breadcrumb.init(); 
    SUI.BrandMore.init(); 
    SUI.Theme.init(); 
    SUI.Agree.init(); 
});


window.addEventListener('load', function() {

    SUI.Vchat.init();
});