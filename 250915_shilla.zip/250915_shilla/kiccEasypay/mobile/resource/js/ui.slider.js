"use strict";

var SUI = SUI || {}; /* global namespace */

/*********************************
 * slider bind JS - https://github.com/nolimits4web/swiper/blob/Swiper5/API.md
 * 
 * MOBILE HTML Layout
 *  
 * <div data-slide=''>                <-- data-slide 로 swiper bind
 *     <ul class="swiper-wrapper">    <-- 필수 class 
 *         <li class="swiper-slide">  <-- 필수 class
 * 
 *         </li>
 *     </ul>
 *     <div class="swiper-pagination"></div>
 * </div>
 * 
 * 
**********************************/

SUI.Slider = {

    init () {
        this.mainVisual();
        this.mainSliders();
        this.subSliders();
        this.producDetailSliders();
        this.actionsheetSliders();
        this.boutiqueSliders();
        this.categoryThemeSliders();
        this.customerCenter();
        this.wishPersonalSlide();
    },

    mainVisual () {
        var mainTop = $('.main_visual');
        var mainSlider = mainTop.find('.visual_list');
        var count = mainTop.find('.count_insert');

        var swiper = new Swiper(mainSlider, {
            slidesPerView: 1,
            spaceBetween:0,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            pagination: {
                el: count,
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span><span class="total">/ ' + total + '</span>';
                }
            },
            observer: true,
            observeParents: true,
        });       
    },

    mainSliders () {
        // trend on
        var trend = $('[data-slide="main_trend_on"]');
        var trendSwiper = new Swiper(trend, {
            slidesPerView: 1,
            spaceBetween:20,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                type: 'bullets',
            },
            observer: true,
            observeParents: true,
        });  

    },

    subSliders () {
        
        // Brand week slide
        var brandReview = new Swiper('[data-slide="brandweek_review"]', {
            centeredSlides: true,
            slidesPerView: 1.12, 
            spaceBetween:10, 
            speed: 500,
            loop: true,
            observer: true,
            observeParents: true,
        });


        // 브랜드샵 목록 - 브랜드 기획전
        var brandSpecial = new Swiper('[data-slide="special_list"]', {
            slidesPerView: 1.22, 
            centeredSlides: true,
            slidesOffsetBefore:-15,
            spaceBetween: 10,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            //loop: true,
            observer: true,
            observeParents: true,
        });

        // only 신라
        var onlySh = new Swiper('[data-slide="online_event"]', {
            slidesPerView: 'auto',
            spaceBetween:10,
            speed: 600,
            pagination: {
                el: '.swiper-pagination',
                type: 'bullets',
            },
            observer: true,
            observeParents: true,
        });  

        // 세일 특가 (할인 기획전)
        var saleBannerSlider = new Swiper('[data-slide="sale_banner"]', {
            slidesPerView: 1,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 400,
            loop: true,
            spaceBetween: 20,
            pagination: {
                el: '.banner_count',
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span><span class="total"> / ' + total + '</span>';
                }
            },
            observer: true,
            observeParents: true,
        });


        // 혜택 배너
        var benefitSlider = new Swiper('[data-slide="benefit_banner_list"]', {
            slidesPerView: 1,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 400,
            loop: true,
            spaceBetween: 0,
            pagination: {
                el: '.banner_count',
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span><span class="total"> / ' + total + '</span>';
                }
            },
            observer: true,
            observeParents: true,
        });


        // 마이신라 출국정보 팝업 scroll mode
        var sairline = new Swiper('[data-slide="airline_list"]', {
            slidesPerView: 2,
            spaceBetween: 5,
            freeMode: true,
            scrollbar: {
                el: '.swiper-scrollbar',
                hide: true,
            },
            observer: true,
            observeParents: true,
        });
        
    },

    producDetailSliders () {
        // 상품상세 이미지 
        var detailImage = $('[data-slide="product_detail_image"]');
        var detailCount = detailImage.find('.visual_count');
        var detailImageSwiper = new Swiper(detailImage, {
            slidesPerView: 1,
            spaceBetween:30,
            loop: true,
            speed: 600,
            pagination: {
                el: detailCount,
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span><span class="total">/ ' + total + '</span>';
                }
            },
            observer: true,
            observeParents: true,
        });

        // AR 컬러 스와이퍼
        var colorList = new Swiper('.color_list', {
            slidesPerView: 'auto',
            spaceBetween:15,
            freeMode: true,
            scrollbar: {
                el: '.swiper-scrollbar',
                hide: true
            },
            observer: true,
            observeParents: true,
            slidesOffsetBefore: 20,
            slidesOffsetAfter : 20
        });

        // 숏폼&포토 리뷰 스와이퍼
        var shortForm = new Swiper('[data-slide="short_form"]', {
            slidesPerView: 'auto',
            spaceBetween: 10,
            freeMode: true,
            observer: true,
            observeParents: true,
            slidesOffsetBefore: 20,
            slidesOffsetAfter : 20
        });

        // 리뷰 포토 스와이퍼
        var reviePhoto = new Swiper('[data-slide="review_photo"]', {
            slidesPerView: 'auto',
            spaceBetween: 10,
            freeMode: true,
            observer: true,
            observeParents: true,
            slidesOffsetBefore: 20,
            slidesOffsetAfter : 20
        });

        var imgList = new Swiper($('[data-slide="img_list"]'), {
            slidesPerView: 1,
            centeredSlides: true,
            loop: true,
            spaceBetween: 0,
            pagination: {
                el: '.img_paging',
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span><span class="total"> / ' + total + '</span>';
                }
            },
            observer: true,
            observeParents: true,
            zoom: {
                maxRatio: 5,
            },   
        });

    },

    // action sheet slide popup
    actionsheetSliders () {
        // 공지 액션시트 팝업 슬라이드
        var notice = $('[data-slide="popup_notice"]');
        var noticeCount = notice.find('.slide_count');
        var noticeSwiper = new Swiper(notice, {
            slidesPerView: 1,
            spaceBetween:30,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            pagination: {
                el: noticeCount,
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span><span class="total"> / ' + total + '</span>';
                }
            },
            observer: true,
            observeParents: true,
        });
    },

    //신라 부티크
    boutiqueSliders (){
        // boutiqueBanner slide 
        var boutiqueBanner = $('[data-slide="boutique_banner"]');
        var boutiqueBannerSlider = new Swiper(boutiqueBanner, {
            slidesPerView: 1,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 400,
            loop: true,
            spaceBetween: 0,
            pagination: {
                el: '.banner_count',
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span><span class="total"> / ' + total + '</span>';
                }
            },
            watchOverflow:true,
            observer: true,
            observeParents: true,
        });

        // banner_item scale
        var bannerList = $('[data-slide="banner_list"]');
        var blSwiper = [];

        var initBannerList = function () {
            bannerList.each(function (i, el) {
                if ( !$(el).find('ul').hasClass('swiper-wrapper') ) {
                    $(el).find('ul').addClass('swiper-wrapper');
                    $(el).find('li').addClass('swiper-slide');
                }

                blSwiper[i] = new Swiper(el, {
                    slidesPerView:1.25,
                    centeredSlides: true,
                    spaceBetween: 5,
                    loop: true,
                    speed: 600,
                    watchOverflow:true,
                    observer: true,
                    observeParents: true,
                });
            })
        }
        initBannerList();

        // banner_item change handler
        var bannerHandler = $('.fashion_content_wrap .btn_wrap button'),
            bannerContent = $('.fashion_content_wrap .fashion_content');

        bannerHandler.on('click', function () {
            var $this = $(this);
            if ($this.hasClass('type1')) {
                $this.removeClass('type1').addClass('type2');
                bannerContent.removeClass('type1').addClass('type2');

                bannerList.each(function (i, el) {
                    blSwiper[i].destroy();
                    blSwiper[i] = [];

                    $(el).find('ul').removeClass('swiper-wrapper');
                    $(el).find('li').removeClass('swiper-slide');
                })
                return;
            }
            
            initBannerList();

            $this.removeClass('type2').addClass('type1');
            bannerContent.removeClass('type2').addClass('type1');

        });
    },

    // 카테고리 - //테마관
    categoryThemeSliders(){
        var themeList = $('[data-slide="theme_list"]');
        var themeList_slider = new Swiper(themeList, {
            centeredSlides: true,
            slidesPerView: 'auto',
            spaceBetween:10,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 400,
            loop: true,
            observer: true,
            observeParents: true,
        });
    },

    customerCenter () {
        // 지점이미지
        var banner = $('.branch_view_list');
        banner.each(function (i, el) {
            new Swiper(el, {
                slidesPerView: 1,
                spaceBetween:20,
                speed: 600,
                loop: true,
                pagination: {
                    el: '.swiper-pagination',
                    type: 'bullets',
                },
                observer: true,
                observeParents: true,
            });  
        });

        // 매장소개 콘텐츠
        var storeList = $('.branch_store_list');
        var storeSwiper = new Swiper(storeList, {
            slidesPerView: 'auto',
            centeredSlides: true,
            spaceBetween: 10,
            // slidesOffsetBefore: 10,
            // slidesOffsetAfter : 10,
            loop: false,
            pagination: false,
            observer: true,
            observeParents: true,
        });  
    },

    // 위시리스트 
    wishPersonalSlide(){
    var sample2 = $('[datas-slide="wish_personal_list"]');
    var sample2_slider = new Swiper(sample2, {
        slidesPerView: 'auto',
        spaceBetween: 0,
        autoplay: {
            delay: 4700,
        },
        speed: 400,
        loop: true,
        observer: true,
        observeParents: true,
    });
    }
}

$(document).ready(() => {
    SUI.Slider.init();
});