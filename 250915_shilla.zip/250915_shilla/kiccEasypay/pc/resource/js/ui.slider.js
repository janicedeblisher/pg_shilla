"use strict";

var SUI = SUI || {}; /* global namespace */

/*********************************
 * slider bind JS - https://github.com/nolimits4web/swiper/blob/Swiper5/API.md
 * 
 * PC HTML Layout
 * -----------------------------------------------------------------------------------
 * 1. 버튼이 슬라이드 영역에 켭치는 HTML tree
 * -----------------------------------------------------------------------------------
 * 
 * data-slide DIV는 버튼 상속을 위하여 감싸주는 역할이며 swiper selector 대상은 그 아래 레벨의 div 임. 
 * 상속 하지 않으면 버튼 div 에도 매칭 할 수 있는 attribute 지정이 필요.
 * 
 * <div data-slide=''>                     <-- data-slide 로 swiper bind
 *     <div class="swiper-container">      <-- overflow:hidden wrapper , swiper 셀렉터 대상
 *          <ul class="swiper-wrapper">    <-- 필수 class 
 *              <li class="swiper-slide">  <-- 필수 class
 * 
 *              </li>
 *          </ul>
 *     </div>
 *     <div class="swiper_hide_arrow small">
 *         <button type="button" class="swiper_prev">이전</button>
 *         <button type="button" class="swiper_next">다음</button>
 *     </div>
 * </div>
 * 
 * -----------------------------------------------------------------------------------
 * 2. 버튼이 없는 슬라이드 영역 HTML tree
 * -----------------------------------------------------------------------------------
 * 
 * <div class="swiper-container" data-slide=''>
 *      <ul class="swiper-wrapper">      <-- 필수 class
 *          <li class="swiper-slide">    <-- 필수 class 
 * 
 *          </li>
 *      </ul>
 * </div>
 * 
 * 재생, 멈춤 
 * @method SUI.slider.playController(target,swiper);
 * @param {Element} target  ex) data-slide selector
 * @param {object} swiper  
 * 
**********************************/

SUI.Slider = {

    init : function () {
        this.mainVisual ();
        this.mainSliders ();
        this.categorySliders ();
        this.quickSliders ();
        this.subSliders ();
    },
    
    playController : function (target, swiper) {
        var stop = target.find('.btn_stop'), 
            play = target.find('.btn_play');

        stop.on('click',function(){
            swiper.autoplay.stop();
            $(this).removeClass('on');
            play.addClass('on');
        })
        play.on('click',function(){
            swiper.autoplay.start();
            $(this).removeClass('on');
            stop.addClass('on');
        }); 
    },

    mainVisual : function () {
        // Visual
        var mainVisual = $('[data-slide="main_visual"]');
        var mainSlider = new Swiper(mainVisual.find('.visual_detail'), {
            slidesPerView: 1,
            effect: 'fade',
            fadeEffect: {
                crossFade: true
            },
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            spaceBetween: 0,
            pagination: {
                el: mainVisual.find('.banner_paging .banner_count'),
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span> <span class="total"> / ' + total + '</span>';
                }
            },
            navigation: {
                prevEl: mainVisual.find('.swiper_prev'),
                nextEl: mainVisual.find('.swiper_next'),
            },
            observer: true,
            observeParents: true,
        });
        this.playController(mainVisual, mainSlider);
    },

    mainSliders : function () {
        var product = $('[data-slide="recommend_product"]');
        var productSwiper = new Swiper(product.find('.product_wrap_outer'), {
            slidesPerView: 4,
            spaceBetween: 20,
            navigation: {
                prevEl: product.find('.swiper_prev'),
                nextEl: product.find('.swiper_next'),
            },
            watchOverflow:true,
            observer: true,
            observeParents: true,
        });


        // 중배너
        var midBanner = $('[data-slide="midBanner"]');
        var midBannerSwiper = new Swiper(midBanner.find('.conts_inner'), {
            slidesPerView: 2,
            spaceBetween: 20,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            hideOnClick: true,
            navigation: {
                prevEl: midBanner.find('.swiper_prev'),
                nextEl: midBanner.find('.swiper_next'),
            },
            watchOverflow:true,
            observer: true,
            observeParents: true,
        });



        // MD's Pick
        var mdPickBanner = $('[data-slide="mdPickBanner"]'),
            mdPick1 = $('[data-slide="mdPick1"]'),
            mdPick2 = $('[data-slide="mdPick2"]');

        var mdPickDefaults = {
            spaceBetween: 16,
            watchOverflow:true,
            observer: true,
            observeParents: true,
        }
        var mdPickSwiper0 = new Swiper(mdPickBanner.find('.thumb_banner'), 
            $.extend(mdPickDefaults, {
                slidesPerView: 1,
                navigation: {
                    prevEl: mdPickBanner.find('.swiper_prev'),
                    nextEl: mdPickBanner.find('.swiper_next'),
                },
            })
        );
        var mdPickSwiper1 = new Swiper(mdPick1.find('.thumb_banner'), 
            $.extend(mdPickDefaults, {
                slidesPerView: 3,
                navigation: {
                    prevEl: mdPick1.find('.swiper_prev'),
                    nextEl: mdPick1.find('.swiper_next'),
                },
            })
        );
        var mdPickSwiper2 = new Swiper(mdPick2.find('.thumb_banner'), 
            $.extend(mdPickDefaults, {
                slidesPerView: 6,
                navigation: {
                    prevEl: mdPick2.find('.swiper_prev'),
                    nextEl: mdPick2.find('.swiper_next'),
                },
            })
        );

        // 팝업
        var popupMall = $('.popup_mall');
        popupMall.each(function(i, el){
            new Swiper($(el).find('.popup_inner'), {
                slidesPerView: 1,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                speed: 600,
                loop: true,
                pagination: {
                    el: $(el).find('.banner_count'),
                    type: 'custom',
                    renderCustom: function (swiper, current, total) {
                        return '<span class="current">' + current + '</span> <span class="total"> / ' + total + '</span>';
                    }
                },
                observer: true,
                observeParents: true,
            });
        });
    },

    categorySliders : function () {
        var defaults = {
            watchOverflow:true,
            observer: true,
            observeParents: true,
        }

        // 카테고리 - 공식스토어 
        var store =  $('[data-slide="category_store"]');
        var storeSwiper = new Swiper(store.find('.store_list'), 
            $.extend(defaults, {
                slidesPerView: 3,
                slidesPerGroup: 4,
                spaceBetween: 10,
                navigation: {
                    prevEl: store.find('.swiper_prev'),
                    nextEl: store.find('.swiper_next'),
                },
            })
        );

        // 카테고리 - 신라Only
        var onlyShilla =  $('[data-slide="category_onlyShilla"]');
        var onlyShillaSwiper = new Swiper(onlyShilla.find('.only_list'),
            $.extend(defaults, {
                slidesPerView: 1,
                slidesPerGroup: 1,
                navigation: {
                    prevEl: onlyShilla.find('.swiper_prev'),
                    nextEl: onlyShilla.find('.swiper_next'),
                },
            })
        );

        // 카테고리 - 테마관
        var theme =  $('[data-slide="category_theme"]');
        var themeSwiper = new Swiper(theme.find('.theme_list'),        
            $.extend(defaults, {
                slidesPerView: 1,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                speed: 600,
                loop: true,
                navigation: {
                    prevEl: theme.find('.swiper_prev'),
                    nextEl: theme.find('.swiper_next'),
                },
            })
        );

        // 통합검색 - 테마관 (scroll mode)
        var theme2 =  $('[data-slide="search_theme"]');
        var theme2Swiper = new Swiper(theme2.find('.theme_list'), {
            slidesPerView: 'auto',
            spaceBetween: 10,
            freeMode: true,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            observer: true,
            observeParents: true,
        });
    },

    quickSliders : function () {
        // 퀵메뉴 이벤트 
        var event = $('[data-slide="event"]');
        event.each(function (){
            var el = $(this);
            new Swiper(el.find('.small_banner'), {
                slidesPerView: 1,
                spaceBetween: 20,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                speed: 600,
                loop: true,
                navigation: {
                    prevEl: el.find('.swiper_prev'),
                    nextEl: el.find('.swiper_next'),
                },
                watchOverflow:true,
                observer: true,
                observeParents: true,
            });
        });

        // 퀵메뉴 쇼핑히스토리
        var history = $('[data-slide="shopping_history"]');
        var historySwiper = new Swiper(history.find('.product_wrap_outer'), {
            slidesPerView: 2,
            slidesPerGroup: 1,
            spaceBetween: 20,
            navigation: {
                prevEl: history.find('.swiper_prev'),
                nextEl: history.find('.swiper_next'),
            },
            watchOverflow:true,
            observer: true,
            observeParents: true,
        });

        // 퀵메뉴 탭 스크롤
        var tabScroll = $('[data-slide="scroll"]');
        var tabScrollSwiper = new Swiper(tabScroll, {
            slidesPerView: 'auto',
            freeMode: true,
            observer: true,
            observeParents: true,
        });
    },

    subSliders : function () {
        // 카테고리 > 배너
        var subBanner = $('[data-slide="subBanner"]');
        var subBannerSwiper = new Swiper(subBanner.find('.sub_banner'), {
            slidesPerView: 1,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            spaceBetween: 0,
            navigation: {
                prevEl: subBanner.find('.swiper_prev'),
                nextEl: subBanner.find('.swiper_next'),
            },
            observer: true,
            observeParents: true,
        });

        this.playController(subBanner, subBannerSwiper);


        // 혜택 > 배너(메인과 동일 / 일시정지, arrow, 카운트)
        var subBannerType2 = $('[data-slide="subBannerType2"]');
        var subBannerSlider = new Swiper(subBannerType2.find('.sub_banner.type2'), {
            slidesPerView: 1,
            // effect: 'fade',
            // fadeEffect: {
            //     crossFade: true
            // },
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            spaceBetween: 0,
            pagination: {
                el: subBannerType2.find('.banner_paging .banner_count'),
                type: 'custom',
                renderCustom: function (swiper, current, total) {
                    return '<span class="current">' + current + '</span> <span class="total"> / ' + total + '</span>';
                }
            },
            navigation: {
                prevEl: subBannerType2.find('.swiper_prev'),
                nextEl: subBannerType2.find('.swiper_next'),
            },
            observer: true,
            observeParents: true,
        });
        this.playController(subBannerType2, subBannerSlider);


        // 3단 이벤트, 기획전 등 이미지 배너 
        var eBenefit =  $('[data-slide="eBenefit"]');
        eBenefit.each(function (){
            var el = $(this);
            new Swiper(el.find('.thumb_banner'), {
                slidesPerView: 3,
                spaceBetween: 20,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                speed: 600,
                loop: true,
                navigation: {
                    prevEl: el.find('.swiper_prev'),
                    nextEl: el.find('.swiper_next'),
                },
                watchOverflow:true,
                observer: true,
                observeParents: true,
            });
        }); 


        // 4단 슬라이드 4개 한묶음으로 이동
        var group4 =  $('[data-slide="product_group4"]');
        group4.each(function (){
            var el = $(this);
            new Swiper(el.find('.product_wrap_outer'), {
                slidesPerView: 4,
                slidesPerGroup: 4,
                spaceBetween: 20,
                navigation: {
                    prevEl: el.find('.swiper_prev'),
                    nextEl: el.find('.swiper_next'),
                },
                watchOverflow:true,
                observer: true,
                observeParents: true,
            });
        });


        // 3단 4단 5단 상품에서 별도로 예외 처리해야할 경우에는 신규로 JS를 생성하여 셀렉터를 특정 영역에 상속하여 적용 )

        // 3단 상품 슬라이드 
        var col3 =  $('[data-slide="product_col3"]');
        col3.each(function (){
            var el = $(this);
            new Swiper(el.find('.product_wrap_outer'), {
                slidesPerView: 3,
                spaceBetween: 20,
                navigation: {
                    prevEl: el.find('.swiper_prev'),
                    nextEl: el.find('.swiper_next'),
                },
                watchOverflow:true,
                observer: true,
                observeParents: true,
            });
        });



        // 4단 상품 슬라이드 - m20
        var col4 =  $('[data-slide="product_col4"]');
        col4.each(function (){
            var el = $(this);
            new Swiper(el.find('.product_wrap_outer'), {
                slidesPerView: 4,
                spaceBetween: 20,
                navigation: {
                    prevEl: el.find('.swiper_prev'),
                    nextEl: el.find('.swiper_next'),
                },
                watchOverflow:true,
                observer: true,
                observeParents: true,
            });
        });


        // 4단 상품 슬라이드 - m10
        var col4 =  $('[data-slide="product_col4_m10"]');
        col4.each(function (){
            var el = $(this);
            new Swiper(el.find('.product_wrap_outer'), {
                slidesPerView: 4,
                spaceBetween: 10,
                navigation: {
                    prevEl: el.find('.swiper_prev'),
                    nextEl: el.find('.swiper_next'),
                },
                watchOverflow:true,
                observer: true,
                observeParents: true,
            });
        });



        // 5단 상품 슬라이드
        var col5 =  $('[data-slide="product_col5"]');
        col5.each(function (){
            var el = $(this);
            new Swiper(el.find('.product_wrap_outer'), {
                slidesPerView: 5,
                spaceBetween: 20,
                navigation: {
                    prevEl: el.find('.swiper_prev'),
                    nextEl: el.find('.swiper_next'),
                },
                watchOverflow:true,
                observer: true,
                observeParents: true,
            });
        });
        

        // 브랜드샵, 명품관 > 기획전
        var brandSpecial =  $('[data-slide="brandSpecial"]');
        var brandSpecialSwiper = new Swiper(brandSpecial.find('.thumb_banner'), {
            slidesPerView: 5,
            spaceBetween: 20,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            speed: 600,
            loop: true,
            navigation: {
                prevEl: brandSpecial.find('.swiper_prev'),
                nextEl: brandSpecial.find('.swiper_next'),
            },
            watchOverflow:true,
            observer: true,
            observeParents: true,
        });
		

        // 상품상세 상단 이미지 썸네일
        var detailThum =  $('[data-slide="detail_thum"]');
        var detailThumSwiper = new Swiper(detailThum.find('.inner_wrap'), {
            slidesPerView: 4,
            spaceBetween: 20,
            centerInsufficientSlides:true,
            navigation: {
                prevEl: detailThum.find('.swiper_prev'),
                nextEl: detailThum.find('.swiper_next'),
            },
            watchOverflow:true,
            observer: true,
            observeParents: true,
        });

        
        // 상품상세 상단 컬러 선택
        var detailThum =  $('[data-slide="color_picker"]');
        var detailThumSwiper = new Swiper(detailThum.find('.opt_color_select'), {
            slidesPerView: 1,
            spaceBetween: 20,
            centerInsufficientSlides:true,
            navigation: {
                prevEl: detailThum.find('.swiper_prev'),
                nextEl: detailThum.find('.swiper_next'),
            },
            watchOverflow:true,
            observer: true,
            observeParents: true,
        });

    },
}

$(document).ready(function(){
    SUI.Slider.init();
});