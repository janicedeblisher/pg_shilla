
$(document).ready(function(){
//<![CDATA[

	/* 인풋 포터스 스타일 */
	$('.txt_type').focus(function(){
		$(this).parent().children('.input_bd').addClass('on');
		if($(this).is(':invalid')) {
			$(this).parent().children('.input_bd').css('border-color','#f95450');
		}
	});
	$('.txt_type').blur(function(){
		$(this).parent().children('.input_bd').removeClass('on');
	});

	/* 버튼 포커스 스타일*/
	$('.btn_list li').on('touchstart', function(){
			$(this).addClass('on');
		}).on('touchend', function(){
			$(this).removeClass('on');
			return false;
	});
	$('.bank_list li, .pay_type_select button').click(function(){
		$(this).addClass('on').siblings().removeClass('on');

	});


	/* 금액 입력 시 천단위 쉼표 처리*/
	$('.money').on('input', inputNumberFormat);

	function inputNumberFormat() {
		console.log(comma(uncomma($(this).val())))
		$(this).val(comma(uncomma($(this).val())));
	}

	function comma(str) {
		str = String(str);
		return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
	}

	function uncomma(str) {
		str = String(str);
		return str.replace(/[^\d]+/g, '');
	}



	/* top버튼 생성 2018-12-28 */
	/*function initTopBtn(){
		var topBtn = '<p id="top" class="topIco"><a href="#">TOP</a></p>';
		var scrollTop = $(window).scrollTop();

		$('.wrap').append($(topBtn));

		$(window).on('scroll', function() {
			scrollTop = $(window).scrollTop();
			if (scrollTop == 0) {
				setTimeout(function() {
					$('#top').hide()
				}, 100);
			} else {
				$('#top').fadeIn();
			}
		});
	}*/


	/* accordion list */
	/*var $accordionList =  $('.accordionList dt');

	$accordionList.on('click', function () {
		if($(this).next().is(':hidden')){
			$(this).closest('li').siblings().removeClass('opened');
			$(this).closest('li').siblings().find('dd').hide();
			$(this).next().show();
			$(this).closest('li').addClass('opened');
		} else {
			$(this).next().hide();
			$(this).closest('li').removeClass('opened');
		}
	});*/
//]]>

});





/* 결제수단  */
$(function(){

	//var PHONE_select = 'select';
	var AGREE_accordion = '[data-js=accordion]';


	$( AGREE_accordion ).length > 0 && agreeAccordion( $( AGREE_accordion ) );
	//$( PHONE_select ).length > 0 && phoneSelect( $( PHONE_select ) );

	//약관동의 아코디언
	function agreeAccordion( target, options ) {

		if( target == undefined || target == null ) return true;

		var containerName = 'agreeAccordion';
		var KEY_anchor = '[data-js=acc_anchor]';
		var KEY_panel = '[data-js=acc_panel]';

		function Setting() {

			$.each(target, function(){
				var self = $(this);
				self.data( containerName , $.extend({
					container : self,
					anchor : self.find( KEY_anchor ),
					panel : self.find( KEY_panel ),
					activeClass : 'active',

					collapsible : false

				}, options, self.data()));

				var option = self.data( containerName );

				AccInit( option );
			});

		}

		function AccInit( obj ) {

			obj.anchor.removeClass( obj.activeClass ).eq( obj.activeIndex ).addClass( obj.activeClass );
			obj.panel.hide().eq( obj.activeIndex ).show();

			AccEvents( obj );

		}


		function AccEvents( obj ) {

			obj.anchor.on('click' + '.' + containerName, function( event ){
				event.preventDefault();
				AccMotion( obj, $(this) );
			});

		}


		function AccIndex(list, iter){

			for (var i = 0; i < list.length; i++) {
				if (iter(list[i])) return i;
			}

		}


		function AccMotion( obj, current ) {
			var idx = AccIndex(obj.anchor, function( key ) { return key === current.get(0) } );

			if (!obj.collapsible) {

				current.toggleClass( obj.activeClass );
				obj.panel.eq( idx ).stop(true).slideToggle();

			} else {

				// Basic
				obj.anchor.removeClass( obj.activeClass ).eq( idx ).addClass( obj.activeClass );
				obj.panel.stop(true).slideUp().eq( idx ).stop(true).slideDown();

			}
		}

		Setting();
	}

	

	$('.select_tel .selText').click(function(){
		$('.select_tel input').removeAttr('checked');
		$('.sort_wrap').addClass('on');
	});
	$('.select_tel .radio_btn').click(function(){
		$('.sort_wrap').removeClass('on');
	});


	//modal popup
	$(document).on("click",".modal_open",function(){
		$('#modal_popup').show();
		var box_h = $(".modal_wrap").height();
		var win_h = $(window).height();
		var h = (win_h - box_h)/2-15;
		if(box_h < win_h){
			$(".modal_wrap").css("margin-top", h);
		}
		else{
			//$(".modal_wrap").css("margin-top", h);
		}
		return false;
	});

	$(".modal_close").click(function(){
		$('#modal_popup').hide();
	});
	
	$('[data-js=popup]').on('click', function(event){
		var popup = $(this).attr('href');
		$( popup ).show().find('.close').on('click', function(){
			$('.modal').hide();
			return false;
		});
		event.preventDefault();
	});


	//캐시내역 최대글자수 기준 너비 맞추기
		var max_w=0;
		$(".c_type4 dt").each(function(){
		var dt_w = parseInt($(this).css("width"));
		if(max_w < dt_w){ max_w = dt_w; }
		});
			$(".c_type4 dt").each(function(){
			$(this).css({width:max_w+2});
		});
			
	/* GNB */
	$('.menu_area,.page_cover').on('click', function ( event ) {
		event.preventDefault();

		if ($('.menu-trigger').hasClass('open')) {
			$('#all_menu,.wrap,.menu-trigger').removeClass('open');
			$('.page_cover').fadeOut(200);
			$('.wrap').off('scroll touchmove mousewheel');
			$('#all_menu,.wrap,.menu-trigger').trigger('change.off');
		} else {
			$('#all_menu,.wrap,.menu-trigger').addClass('open');
			$('.page_cover').fadeIn(200);
			$('.wrap').on('scroll touchmove mousewheel', function (e) {
					e.preventDefault();
					e.stopPropagation();
					return false;
			});
			$('#all_menu,.wrap,.menu-trigger').trigger('change.on');
			window.location.hash = "#menu_open";
		}
	});

	window.onhashchange = function () {
		if (location.hash != '#menu_open') {
			$('#all_menu,.wrap,.menu-trigger').removeClass('open');
			$('.page_cover').fadeOut(200);
			$('.wrap').off('scroll touchmove mousewheel');
		}
	};

	$(window).on('scroll', function() {
		scrollTop = $(window).scrollTop();
		subHome = $('.sub_app .new_header');
		var homeTop = Math.abs(parseInt(subHome.css('top')));
		if (scrollTop > homeTop) {
			$('.gnb').addClass('on');
		} else {
			$('.gnb').removeClass('on');
		}
	});

	/* 신라페이 간편결제 결제수단 관리 */
	!(function favoriteEditList(){
		var component = $('[data-js=favoriteEditList]');
		var key = {
			componentName : 'favoriteEditList',
			KEY_total : '[data-favorite=total]',
			KEY_item : '[data-favorite=item]',
		};

		if (component.length > 0) {

			component.data(key.componentName, new favoriteEditSetting( component ));
		}

		function favoriteEditSetting( el ) {

			this._this = $(el);
			this._options = {
				total : this._this.find( key.KEY_total ),
				item : this._this.find( key.KEY_item ),
				
			}

			init( this._options );
			
		};
		

		function init( obj ) {

			initializeEvents( obj );

		};

		function initializeEvents( obj ){

			obj.total.sortable({
				revert : true,
				handle : "a.label",
				scrollSensitivity : 200,
				containment : "parent"
			});

			obj.total.find( key.KEY_item ).disableSelection();
			
		}

	})();

	
});

/* iOS Statusbar 대응 2020-04-24 */
$(function(){

	var fnApplyStatus = (function(){
		var appEl = '.ios',
			dataNative = '[data-native]';

		var init = function(target){

			dataNative = target || '[data-native]';

			console.log('$(dataNative)', $(dataNative));

			$(dataNative).length && $(dataNative).each(function(){
				var _target = $(this);

				setStatus(_target);
			});
		};

		var setStatus = function(target){
			var statusHeight = getStatusHeight();
			var targetEl =  target;
			var isStatus = targetEl[0].dataset.native == 'status';
			var isClose = targetEl[0].dataset.native == 'close';
			var isSticky = targetEl[0].dataset.native == 'sticky';
			var styled = targetEl.length && getComputedStyle(targetEl[0]);

			if(isStatus){
				(styled.position == 'absolute' || styled.position == 'fixed')  ? targetEl.css('top', statusHeight+'px') : targetEl.css('padding-top', statusHeight+'px');
			}

			if(isClose){
				var origTop = parseInt(targetEl.css('top'));
				targetEl.on('change.on', function(){
					var top =  parseInt(targetEl.css('top'));
					targetEl.css('top', (statusHeight+top)+'px');
					console.log(statusHeight+top);
				});
				targetEl.on('change.off', function(){
					targetEl.css('top', origTop+'px');
				});
			}
			if(isSticky){
				var top =  parseInt(targetEl.css('top'));
				targetEl.css('top', (top + statusHeight)+'px');
			}
		};
		
		/* data- 높이값 가져오기 */
		var getStatusHeight = function(){
			return parseInt($(appEl)[0].dataset.status);
		};

		return {
			init: init
		}

	}());

	$('.ios').length && fnApplyStatus.init();
});
