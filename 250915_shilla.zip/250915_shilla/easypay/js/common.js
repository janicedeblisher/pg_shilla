function f_win_open( url, name, w, h )
{
    //firefox
    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left;
    var dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top;

    var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

    var left = ( ( width / 2 ) - ( w / 2 ) ) + dualScreenLeft;
    var top = ( ( height / 2 ) - ( h / 2 ) ) + dualScreenTop;

    var sst = window.open( url, name, "width=" + w + ",height=" + h + ",left=0 ,top=0, toolbars=no, resizable=no, scrollbars=no" );
    if( sst )
    {
        sst.focus();
    }
    
    return sst;
}

function f_show_layer(layerId){
    if($("#dimmedLayer").size() > 0){
        $("#dimmedLayer").remove();
    }
    $(layerId).before("<div id='dimmedLayer' class='dimmedLayer'></div>");
    $("#dimmedLayer").height($("window").height());
    $(layerId).show();  
}

function f_hide_layer(layerId){
    if($("#dimmedLayer").size() > 0){
        $("#dimmedLayer").remove();
    }
    $(layerId).hide(); 
}

function f_is_checked_img(elem){
    var src = $(elem).attr("src");
    if(src.indexOf("chk1.png") > -1){
        // checked
        return true;
    }else{
        // not checked
        return false;
    }
}

function f_toggle_checked_img(elem, checked){
    if(f_is_null(checked)){
        if($(elem).attr("src").indexOf("chk1.png") > -1){
            // as is checked
            // to not check
            checked = true;
        }else{
            // as is not checked
            // to check
            checked = false;
        }
    }
    
    if(checked){
        // checked
        // to not check
        var src = $(elem).attr("src");
        src = src.replace("chk1.png", "chk.png");
        $(elem).attr("src", src);
    }else{
        // not checked
        // to check
        var src = $(elem).attr("src");
        src = src.replace("chk.png", "chk1.png");
        $(elem).attr("src", src);
    }
}

function f_toggle_child_view(elem){
    $(elem).toggle("fast", function(){
        //console.log("f_toggle_child_view complete");
    });
}

function f_is_empty(data){
    if(!f_is_null(data)){
        
        if($.type(data) == "string"){
            data = data.trim();
            if(data != 'null' && data != 'undefined' && data != undefined && data.length > 0){
                return false;
            }    
        } else if($.type(data) == "number"){
            if(data < 1){ // �̰� ���ǰ� �ʿ��ҵ�
                return false;
            }
        } else if($.type(data) == "array"){
            if(data.length < 1){
                return false;
            }
        } else if($.type(data) == "boolean"){
            return data;
        } 
    }
    return true;
}

function f_find_map_array(arry, type, key, param1){
    if(!f_is_null(arry)){
        for(var i=0; i<arry.length; i++){
            if(type == "equal"){
                var obj = arry[i];
                var compareData = param1;
                if(obj[key] == compareData){
                    // call by ref
                    return arry[i]; 
                }
            }else if(type == "num_equal"){
                var obj = arry[i];
                var compareData = param1;
                if(parseInt(obj[key]) == parseInt(compareData)){
                    // call by ref
                    return arry[i]; 
                }
            }
        }
    }
    
    return null;
}

function f_find_array(arry, type, param1){
    if(!f_is_null(arry)){
        for(var i=0; i<arry.length; i++){
            if(type == "equal"){
                var compareData = param1;
                if(arry[i] == compareData){
                    // call by ref
                    return arry[i]; 
                }
            } else if(type == "num_equal"){
                var obj = arry[i];
                var compareData = param1;
                if(parseInt(arry[i]) == parseInt(compareData)){
                    // call by ref
                    return arry[i]; 
                }
            }
        }
    }
    return null;
}

function f_remove_array(arry, remove_list, key){
    if(!f_is_null(arry)){
        var compareList = remove_list;

        return $.grep(arry, function (v, i){
            for(var r=0; compareList.length; r++){
//                if(needParseInt){
//                    v = parseInt(v);
//                }
                
                if(compareList[r] != v[key]){
                    return true;
                }else{
                    return false;
                }
            }
        });
    }
    return null;
}

function f_is_null(data){
    if($.type(data) == "boolean"){
        return false;
    }else if(data == null || data == "null" || data == "undefined" || data == undefined || data == ""){
        return true;
    }
    return false;
}

function f_get_deviceH(){
    var height = window.screen.height;
    if((navigator.userAgent.match(/iPhone/i)) ||  (navigator.userAgent.match(/iPod/i))) {
        // taskbar_except_height
        var browser = f_getBrowser();
        if("safari" == browser) {
            height = window.screen.availHeight -80;
        }
    }
    return height;
}

function f_get_deviceW(){
    var width = $(window).width();
    if((navigator.userAgent.match(/iPhone/i)) ||  (navigator.userAgent.match(/iPod/i))) {
        // taskbar_except_height
        width = $(window).width();
    }
    
    return width;
}

function f_convert_price_display(product_amt){
    product_amt = product_amt + "";
    if(product_amt.indexOf(",") > -1){
        product_amt = product_amt.split(",").join("");
    }else{
        if(product_amt.length > 3){
            var len = product_amt.length-1, loopCnt = Math.floor(len / 3), index = 0;
            for ( var i = 0; i < loopCnt; i++ )
            {
                index =  (3*(i+1))+i;
                product_amt = insertAt(product_amt, ",", product_amt.length-index);
            }
        }
    }
    return product_amt;
}

function insertAt(origin, data, index){
    return [origin.substr(0,index), data, origin.substr(index)].join("");
}

function parseUrlQuery(str){
    try{
        if(str.indexOf("?") > -1){
            // extract query str from full url
            var idx = str.indexOf("?"); 
            str = str.substr(idx, str.length-idx+1);
        }
        
        var dataArr = str.split("&");
        var obj = {}, key, val;
        var pair;
        for(var i in dataArr){
            pair = dataArr[i];
            key = pair.split("=")[0];
            val = pair.split("=")[1];
            obj[key] = val;
        }
    }catch(exception){
        alert("parseUrlQuery Error : "+ str);
        obj = null;
    }finally{
        return obj;
    }
}

jQuery.support.cors = true;
function getDefaultAjaxOption(requestUrl, formData, callback){
    return getDefaultAjaxOption(requestUrl, formData, callback, "");
}

function getDefaultAjaxOption(requestUrl, formData, callback, dataType){
    var option = {
        type : "POST",
        url : requestUrl,
        data : formData,
        crossDomain: true,
        success : function(data) {
            if( data == "" || data == null ){
                if(!f_is_null(console)){
                    console.log(data);
                }
            }
            callback(data);
        },
        complete : function(data) {
        },
        error : function(request, status, error) {
            alert( "code:" + request.status + "\n"+"message:" + request.responseText + "\n" + "error:" + error );
        }
    };
    
    if(!f_is_empty(dataType)){
        option.dataType = dataType;
    }
    
    return option;
}

function doRequest(url, data){
    doRequest(url, data, function(data){});
}

function doRequest(url, data, callback){
    doRequest(url, data, callback, "");
}

function doRequest(url, data, callback, dataType){
    var requestUrl = url;
    var formData;
    if($.type(data) == "string"){
        formData = data
    }else if($.type(data) == "object"){
        formData = $.param(data);
    }
    var option = getDefaultAjaxOption(requestUrl, formData, callback, dataType);
    $.ajax(option);
}


function item_layer_resize(item_arry, layer_root, wb_root, padding, top_position, item_identity, item_default_width, funcOption){
    
    var row_item_cnt = 3;
    if(!f_is_null(item_arry) && item_arry.length < 3){
        row_item_cnt = item_arry.length;
    }
    
    var wb = $(wb_root);
    var wb_container = $(wb).parent();
    var wb_item = $(item_identity);
    var device_width = f_get_deviceW();
    var basic_wb_width = (device_width - padding);
    var item_width = item_default_width;
    var wb_max_width = item_width*row_item_cnt;
    //var wb_min_width = item_width;
    var wb_width;
    
    // wb
    var transform_rate = 0.9;
    transform_rate = (basic_wb_width/3)/item_width;
    item_width = basic_wb_width/3;
    wb_max_width = item_width*3;
    
    // align-center
    $(wb).css("text-align", "center");
    wb_width = wb_max_width;
    
    $(wb).css("max-width", wb_width+"px");
    $(wb).width(wb_width);
    
    if(!f_is_null(funcOption)){
        funcOption(wb_item, item_width);
    }
    
    // height
    $(layer_root).css("top", top_position+"px");
    
    var left_margin = (device_width - wb_width - padding)/2;
    $(layer_root).css("margin-left", left_margin+"px");
}

/**
 * keys key array
 * @param obj
 * @param keys
 */
function f_disableKeyCode(obj, keys){
    
    $(obj).keydown(function(e){
        for(i in keys){
            if(e.which == keys[i]){
                return false;
            }
        }
    });
    
}

function f_getBrowser(){
    var userAgent = navigator.userAgent.toLowerCase();
    // daum, naver, chrome ios, android chrome, safari ���� �߿���
    if(userAgent.indexOf("samsungbrowser") > -1) return "samsung";
    else if(userAgent.indexOf("daumapps") > -1) return "daum";
    else if(userAgent.indexOf("naver") > -1 && userAgent.indexOf("inapp") > -1) return "naver";
    else if(userAgent.indexOf("crios") > -1) return "crios";
    else if(userAgent.indexOf("chrome") > -1) return "chrome";
    else if(userAgent.indexOf("safari") > -1) return "safari";
    else return "";
} 

function f_getOs(){
    var userAgent = navigator.userAgent.toLowerCase();
    // WINDOWS, MACINTOSH, ANDROID, IOS
    if(userAgent.indexOf("window") > -1) return "WI";
    else if(userAgent.indexOf("macintosh") > -1) return "MA";
    else if(userAgent.indexOf("android") > -1) return "AN";
    else if(userAgent.indexOf("iphone") > -1 || userAgent.indexOf("ipad") > -1 || userAgent.indexOf("ipod") > -1) return "IO";
    else return "";
} 

function f_doPolling(pst, pp, pd, check, success, errback){
    setTimeout(function(){f_poll(check, success, errback, pp, pd);}, pst);
}

function f_poll(fn, callback, errback, timeout, interval) {
    var endTime = Number(new Date()) + (timeout || 2000);
    interval = interval || 100;
    (function p() {
            if(fn()) {
                callback();
            }
            else if (Number(new Date()) < endTime) {
                setTimeout(p, interval);
            }
            else {
                errback(new Error('timed out for ' + fn + ': ' + arguments));
            }
    })();
}

function f_doPolling2(pst, pp, pd, check, success, errback){
    setTimeout(function(){f_poll2(check, success, errback, pp, pd);}, pst);
}

function f_poll2(fn, callback, errback, timeout, interval) {
    (function() {
        var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
        window.requestAnimationFrame = requestAnimationFrame;
    })();
    var endTime = Number(new Date()) + (timeout || 2000);
    interval = interval || 100;
    (function p() {
            if(fn()) {
                callback();
            }
            else if (Number(new Date()) < endTime) {
                setTimeout(function(){requestAnimationFrame(p);}, interval);
            }
            else {
                errback(new Error('timed out for ' + fn + ': ' + arguments));
            }
    })();
}


function numberFilter(event){
    
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;

    if(keyID == 13){
        return false;
    }
    if(keyID == 8 || keyID == 9 ){
        return;
    }
    
    event.target.value = String(event.target.value).replace(/^\s+|\s+$/g,"");
    
    event.target.value = event.target.value.replace(/[^0-9]/g, "");
    
}

function autoFocus(event, length, dest){
    
    event = event || window.event;

    if(isNum(length) && !f_is_null(dest)){
        if(event.target.value.length > length ){
            event.target.value = event.target.value.substr(0, length);
        }
        
        if(event.target.value.length >= length ){
            $(dest).focus();
            return;
        }
    }
    
}


function removeChar2(event, length){
    
    event = event || window.event;

    event.target.value = String(event.target.value).replace(/^\s+|\s+$/g,"");
    
    event.target.value = event.target.value.replace(/[^0-9]/g, "");
    
    if(isNum(length)){
        if(event.target.value.length >= length ){
            event.target.value = event.target.value.substring(0, length-1);
        }
    }
}

function isNum(num){
    var regex = /^[0-9]$/g;
    num = String(num).replace(/^\s+|\s+$/g,"");
    
    if(regex.test(num)){
        num=num.replace(/,/g, "");
        return isNaN(num) ? false : true;
    }else{return false;}
}

function onlyNumber(event, length){
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;

    if(keyID == 8 || keyID == 9 ){
        return;
    }
    
    if(keyID == 13){
        return false;
    }
    
    if(event.target.value.length >= length ){
        event.target.value = event.target.value.substring(0, length-1);
    }
    return;
}

function removeChar(event) {
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    if ( keyID == 8 || keyID == 9 || keyID == 13) 
        return;
    else
        event.target.value = event.target.value.replace(/[^0-9]/g, "");
}

// form serialize
function serialize(form, charset) {
    var field, s = [];
    if (typeof form == 'object' && form.nodeName.toLowerCase() == "form") {
        var len = form.elements.length;
        for (i=0; i<len; i++) {
            field = form.elements[i];
            if (field.name && !field.disabled && field.type != 'file' && field.type != 'reset' && field.type != 'submit' && field.type != 'button') {
                if (field.type == 'select-multiple') {
                    for (j=form.elements[i].options.length-1; j>=0; j--) {
                        if(field.options[j].selected)
                            s[s.length] = field.name + "=" + field.options[j].value;
                    }
                } else if ((field.type != 'checkbox' && field.type != 'radio') || field.checked) {
                    if(charset == "UTF-8" && field.name == "sp_res_msg")
                        field.value = decodeURIComponent(field.value);
                    s[s.length] = field.name + "=" + field.value;
                }
            }
        }
    }
    return s.join('&');
}

function maxLengthCheck(obj){
    
    if(obj.value.length > obj.maxLength){
        obj.value = obj.value.substr(0,obj.maxLength);
    }
    obj.value = obj.value.replace(/\./g, "");
}

function f_get_scrollH(){
    var deviceH = f_get_deviceH();
    
    var contentBody = document.getElementById("wrap");
    if(!f_is_null(contentBody)){
        if(contentBody.scrollHeight < deviceH){
            deviceH = contentBody.scrollHeight 
        }
    }
    
    $("body div").eq(0).height(deviceH);
    $("body div").eq(0).css("border", "1px solid #000000");
    $("body div").eq(0).css("overflow", "scroll"); 
}


function decEnti(str){
    var textVal = document.createElement("textarea");
    textVal.innerHTML = str;
    return textVal.value;
}

function f_change_lang(lang){
    $.ajax( {
        url : "/ep8/common/AddReqDataAction.do",
        type : "post",
        async : false,
        dataType : "json",
        data : {
            trace_no : document.frm_reentry.trace_no.value,
            sp_lang_flag : lang
        },
        success : function( data ){
            var frm = document.frm_reentry;
            frm.submit();
        },
        error : function ( request, status, error ) {
            alert( "code:" + request.status + "\n" + "message:" + request.responseText + "\n" + "error:" + error );
        }
    });
    return false;
}

/*
jQuery deparam is an extraction of the deparam method from Ben Alman's jQuery BBQ
http://benalman.com/projects/jquery-bbq-plugin/
*/
(function ($) {
$.deparam = function (params, coerce) {
  var obj = {},
      coerce_types = { 'true': !0, 'false': !1, 'null': null };
    
  // Iterate over all name=value pairs.
  $.each(params.replace(/\+/g, ' ').split('&'), function (j,v) {
    var param = v.split('='),
        key = decodeURIComponent(param[0]),
        val,
        cur = obj,
        i = 0,
          
        // If key is more complex than 'foo', like 'a[]' or 'a[b][c]', split it
        // into its component parts.
        keys = key.split(']['),
        keys_last = keys.length - 1;
      
    // If the first keys part contains [ and the last ends with ], then []
    // are correctly balanced.
    if (/\[/.test(keys[0]) && /\]$/.test(keys[keys_last])) {
      // Remove the trailing ] from the last keys part.
      keys[keys_last] = keys[keys_last].replace(/\]$/, '');
        
      // Split first keys part into two parts on the [ and add them back onto
      // the beginning of the keys array.
      keys = keys.shift().split('[').concat(keys);
        
      keys_last = keys.length - 1;
    } else {
      // Basic 'foo' style key.
      keys_last = 0;
    }
      
    // Are we dealing with a name=value pair, or just a name?
    if (param.length === 2) {
      val = decodeURIComponent(param[1]);
        
      // Coerce values.
      if (coerce) {
        val = val && !isNaN(val)              ? +val              // number
            : val === 'undefined'             ? undefined         // undefined
            : coerce_types[val] !== undefined ? coerce_types[val] // true, false, null
            : val;                                                // string
      }
        
      if ( keys_last ) {
        // Complex key, build deep object structure based on a few rules:
        // * The 'cur' pointer starts at the object top-level.
        // * [] = array push (n is set to array length), [n] = array if n is 
        //   numeric, otherwise object.
        // * If at the last keys part, set the value.
        // * For each keys part, if the current level is undefined create an
        //   object or array based on the type of the next keys part.
        // * Move the 'cur' pointer to the next level.
        // * Rinse & repeat.
        for (; i <= keys_last; i++) {
          key = keys[i] === '' ? cur.length : keys[i];
          cur = cur[key] = i < keys_last
            ? cur[key] || (keys[i+1] && isNaN(keys[i+1]) ? {} : [])
            : val;
        }
          
      } else {
        // Simple key, even simpler rules, since only scalars and shallow
        // arrays are allowed.
          
        if ($.isArray(obj[key])) {
          // val is already an array, so push on the next value.
          obj[key].push( val );
            
        } else if (obj[key] !== undefined) {
          // val isn't an array, but since a second value has been specified,
          // convert val into an array.
          obj[key] = [obj[key], val];
            
        } else {
          // val is a scalar.
          obj[key] = val;
        }
      }
        
    } else if (key) {
      // No value was defined, so set something meaningful.
      obj[key] = coerce
        ? undefined
        : '';
    }
  });
    
  return obj;
};
})(jQuery);
