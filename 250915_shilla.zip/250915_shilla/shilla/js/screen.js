$(document).ready(function() {

	// mobile button active
	$(document).on('touchstart',function(){});

	// select common
	$('select').on('change',function(){
		$(this).addClass('active');
	});

	// input delete buttton show
	function inpCheck(){
		var inp = $('input');
		inp.keyup(function(){
			var str = $(this).val();
			$(this).val(str.replace(/(^\s+)|(\s+$)/gm, ""));
			if(str != ""){
				$(this).parent(".inputArea").addClass("active");
			}else{
				$(this).parent(".inputArea").removeClass("active");
			}
		});
		inp.focus(function(){
			var str = $(this).val();
			$(this).val(str.replace(/(^\s+)|(\s+$)/gm, ""));
			if(str != ""){
				$(this).parent(".inputArea").addClass("active");
			}
		});
	};
	inpCheck();

	$('.btnInputDel').click(function(){
		$(this).prev('input').val('');
		$(this).parent(".inputArea").removeClass("active");
	});
	
	$('.inputArea input').keyup(function(){
		$(this).parent(".inputArea").addClass("active");
	});
	
});

//공통 사용 modal
var _ModalPopupBackgroundID = 'modal';
function ShowModalPopup(modalPopupID) {
	var popupID = "#" + modalPopupID;
	var popupMarginTop = $(popupID).height() / 2;
	var popupMarginLeft = $(popupID).width() / 2;
	$('body').css('overflow', 'hidden');
	$(popupID).css({
		'left': '50%',
		'top': '50%',
		'margin-top': -popupMarginTop,
		'margin-left': -popupMarginLeft,
		'display': 'block',
		'position': 'fixed',
		'z-index': 99999
	});

	var backgroundSelector = $('<div id="' + _ModalPopupBackgroundID + '" ></div>');
	backgroundSelector.appendTo('body');

	backgroundSelector.css({
		'width': $(document).width(),
		'height': $(document).height(),
		'display': 'none',
		'background-color': '#000',
		'filter':'alpha(opacity=70)',
		'position': 'absolute',
		'top': 0,
		'left': 0,
		'z-index': 99998
	});

	backgroundSelector.fadeTo('fast', 0.8);
		 backgroundSelector.click(function(){
			 HideModalPopup(modalPopupID)
		});

}

function HideModalPopup(modalPopupID) {
	$("#" + modalPopupID).css('display', 'none');
	$("#" + _ModalPopupBackgroundID).remove();
	$('body').css('overflow', 'auto');
}